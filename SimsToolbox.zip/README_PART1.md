# SimsToolbox - Part 1 (主界面)

这是第 1 部分：**工具箱主界面**（一个 Tk Root + 按钮面板 + 模块加载器）。

## 运行

Windows PowerShell:

```powershell
python toolbox.py
```

或双击：`run_toolbox.bat`

## 数据目录

默认会在项目根目录生成 `_user_data/`，用于保存配置文件：
- `_user_data/toolbox_settings.json`

你也可以通过环境变量指定数据目录：
- `SIMS_TOOLBOX_DATA=...`

## 后续合并方式（你手动组合 4 个部分）

- 解压 Part 1
- 再解压 Part 2/3/4 覆盖到同一目录即可（会覆盖 `modules/*` 下对应模块）
