from __future__ import annotations

import tkinter as tk

from toolbox_app import ToolboxApp


def main() -> None:
    root = tk.Tk()
    app = ToolboxApp(root)
    app.run()


if __name__ == "__main__":
    main()
