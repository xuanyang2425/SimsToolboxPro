from __future__ import annotations

import tkinter as tk


def copy_to_clipboard(widget: tk.Misc, text: str) -> None:
    """Backwards compatible clipboard helper."""
    try:
        widget.clipboard_clear()
        widget.clipboard_append(text)
    except Exception:
        pass


def copy_text(widget: tk.Misc, text: str) -> None:
    """Alias used by newer modules."""
    copy_to_clipboard(widget, text)
