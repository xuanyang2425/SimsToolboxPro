from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from core.paths import get_settings_path


class ConfigStore:
    """Simple JSON settings store.

    Designed to stay stable so future modules can rely on it.
    """

    def __init__(self, app_dir: str):
        self.app_dir = app_dir
        self.path = Path(get_settings_path(app_dir))
        self._data: dict[str, Any] = {}

    def load(self) -> None:
        if self.path.exists():
            try:
                self._data = json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                self._data = {}
        else:
            self._data = {}

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data.setdefault("_meta", {})
        self._data["_meta"]["updated_at"] = int(time.time())
        self.path.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self._data[key] = value

    def append_history(self, key: str, value: str, limit: int = 30) -> None:
        value = (value or "").strip()
        if not value:
            return
        arr = list(self._data.get(key, []))
        arr = [x for x in arr if str(x) != value]
        arr.insert(0, value)
        self._data[key] = arr[:limit]

    def as_dict(self) -> dict[str, Any]:
        return dict(self._data)
