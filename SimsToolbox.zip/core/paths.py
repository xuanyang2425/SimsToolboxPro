from __future__ import annotations

import os
from pathlib import Path


def get_project_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def get_app_dir() -> str:
    """Persistent data dir.

    - If SIMS_TOOLBOX_DATA is set, use it.
    - Else use <project>/_user_data (portable, stays with the folder).
    """
    env = os.environ.get("SIMS_TOOLBOX_DATA", "").strip()
    if env:
        p = Path(env).expanduser().resolve()
    else:
        p = get_project_dir() / "_user_data"
    p.mkdir(parents=True, exist_ok=True)
    return str(p)


def get_settings_path(app_dir: str | None = None) -> str:
    base = Path(app_dir or get_app_dir())
    return str(base / "toolbox_settings.json")
