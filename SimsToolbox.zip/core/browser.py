from __future__ import annotations

import os
import platform
import subprocess
import webbrowser
from pathlib import Path


def open_url(url: str) -> None:
    if not url:
        return
    webbrowser.open(url)


def open_path(path: str) -> None:
    if not path:
        return
    p = Path(path)
    if not p.exists():
        return

    sys = platform.system().lower()
    try:
        if sys.startswith("windows"):
            os.startfile(str(p))  # type: ignore[attr-defined]
        elif sys == "darwin":
            subprocess.run(["open", str(p)], check=False)
        else:
            subprocess.run(["xdg-open", str(p)], check=False)
    except Exception:
        pass
