from __future__ import annotations

import os
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox
from tkinter import ttk

from core.browser import open_path

from . import service


CFG_PREFIX = "tray_converter."


class TrayConverterWindow:
    def __init__(self, root: tk.Tk, cfg):
        self.root = root
        self.cfg = cfg
        self.stop_event = threading.Event()

        win = tk.Toplevel(root)
        self.win = win
        win.title("Tray 版本转换器")
        win.geometry(cfg.get(CFG_PREFIX + "geometry", "980x640"))
        win.minsize(880, 560)
        win.protocol("WM_DELETE_WINDOW", self.on_close)

        # state vars
        self.in_path = tk.StringVar(value=cfg.get(CFG_PREFIX + "in_path", ""))
        self.ref_path = tk.StringVar(value=cfg.get(CFG_PREFIX + "ref_path", ""))
        self.out_path = tk.StringVar(value=cfg.get(CFG_PREFIX + "out_path", str(Path.cwd() / "downgraded_tray")))
        self.manual_version = tk.StringVar(value=cfg.get(CFG_PREFIX + "manual_version", ""))

        self.copy_associated = tk.BooleanVar(value=cfg.get(CFG_PREFIX + "copy_associated", True))
        self.overwrite = tk.BooleanVar(value=cfg.get(CFG_PREFIX + "overwrite", False))
        self.dry_run = tk.BooleanVar(value=cfg.get(CFG_PREFIX + "dry_run", False))
        self.recursive = tk.BooleanVar(value=cfg.get(CFG_PREFIX + "recursive", True))

        default_workers = max(2, min(8, (os.cpu_count() or 4) // 2))
        self.workers = tk.IntVar(value=int(cfg.get(CFG_PREFIX + "workers", default_workers)))

        self.detected_version = tk.StringVar(value="（未检测）")
        self.detected_path = tk.StringVar(value="")
        self.status_text = tk.StringVar(value="就绪")

        self._build_ui()

    def _build_ui(self) -> None:
        pad = 10
        root = ttk.Frame(self.win, padding=pad)
        root.pack(fill=tk.BOTH, expand=True)

        # Input
        r0 = ttk.Frame(root)
        r0.pack(fill=tk.X, pady=(0, 6))
        ttk.Label(r0, text="输入（.trayitem 文件或文件夹）：", width=30).pack(side=tk.LEFT)
        ttk.Entry(r0, textvariable=self.in_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        ttk.Button(r0, text="选择文件…", command=self._pick_in_file).pack(side=tk.LEFT)
        ttk.Button(r0, text="选择文件夹…", command=self._pick_in_dir).pack(side=tk.LEFT, padx=(6, 0))

        # Reference
        r1 = ttk.Frame(root)
        r1.pack(fill=tk.X, pady=6)
        ttk.Label(r1, text="参考 .trayitem（低版本游戏保存的）：", width=30).pack(side=tk.LEFT)
        ttk.Entry(r1, textvariable=self.ref_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        ttk.Button(r1, text="选择…", command=self._pick_ref).pack(side=tk.LEFT)
        ttk.Button(r1, text="检测", command=self._detect_ref).pack(side=tk.LEFT, padx=(6, 0))

        r1b = ttk.Frame(root)
        r1b.pack(fill=tk.X)
        ttk.Label(r1b, text="检测到版本：", width=30).pack(side=tk.LEFT)
        ttk.Label(r1b, textvariable=self.detected_version).pack(side=tk.LEFT)
        ttk.Label(r1b, text="字段路径：").pack(side=tk.LEFT, padx=(16, 0))
        ttk.Label(r1b, textvariable=self.detected_path).pack(side=tk.LEFT, fill=tk.X, expand=True)

        # Manual version
        r2 = ttk.Frame(root)
        r2.pack(fill=tk.X, pady=6)
        ttk.Label(r2, text="或手动设置版本号（8 位十六进制）：", width=30).pack(side=tk.LEFT)
        ttk.Entry(r2, textvariable=self.manual_version, width=16).pack(side=tk.LEFT)
        ttk.Label(r2, text="例：00002BC0").pack(side=tk.LEFT, padx=(8, 0))

        # Output
        r3 = ttk.Frame(root)
        r3.pack(fill=tk.X, pady=6)
        ttk.Label(r3, text="输出目录：", width=30).pack(side=tk.LEFT)
        ttk.Entry(r3, textvariable=self.out_path).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 8))
        ttk.Button(r3, text="选择…", command=self._pick_out).pack(side=tk.LEFT)
        ttk.Button(r3, text="打开", command=self._open_out).pack(side=tk.LEFT, padx=(6, 0))

        # Options
        opt = ttk.Frame(root)
        opt.pack(fill=tk.X, pady=(6, 6))
        ttk.Checkbutton(opt, text="复制同组关联文件（推荐）", variable=self.copy_associated).pack(side=tk.LEFT)
        ttk.Checkbutton(opt, text="覆盖输出（谨慎）", variable=self.overwrite).pack(side=tk.LEFT, padx=(10, 0))
        ttk.Checkbutton(opt, text="递归扫描子文件夹", variable=self.recursive).pack(side=tk.LEFT, padx=(10, 0))
        ttk.Checkbutton(opt, text="仅演练（不写文件）", variable=self.dry_run).pack(side=tk.LEFT, padx=(10, 0))

        opt2 = ttk.Frame(root)
        opt2.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(opt2, text="并发线程：").pack(side=tk.LEFT)
        ttk.Spinbox(opt2, from_=1, to=16, textvariable=self.workers, width=6).pack(side=tk.LEFT)
        ttk.Label(opt2, text="（建议 2-8）").pack(side=tk.LEFT, padx=(8, 0))

        # Controls
        ctrl = ttk.Frame(root)
        ctrl.pack(fill=tk.X, pady=(0, 8))
        ttk.Button(ctrl, text="开始", command=self._start).pack(side=tk.LEFT)
        ttk.Button(ctrl, text="停止", command=self._stop).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Button(ctrl, text="清空日志", command=self._clear_log).pack(side=tk.LEFT, padx=(8, 0))

        self.progress = ttk.Progressbar(root, mode="determinate")
        self.progress.pack(fill=tk.X)

        # Log
        logfrm = ttk.Frame(root)
        logfrm.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
        self.log = tk.Text(logfrm, height=16, wrap="word")
        self.log.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb = ttk.Scrollbar(logfrm, orient="vertical", command=self.log.yview)
        sb.pack(side=tk.LEFT, fill=tk.Y)
        self.log.configure(yscrollcommand=sb.set)

        # Status
        status = ttk.Label(self.win, textvariable=self.status_text, anchor="w")
        status.pack(fill=tk.X, side=tk.BOTTOM)

        self._log("[提示] 这是 Tray 版本转换器模块（第 2 部分）。")
        self._log("[提示] 处理完成后建议删除一次 localthumbcache.package。")

    # ---------- UI helpers ----------
    def _log(self, s: str) -> None:
        self.log.insert("end", s + "\n")
        self.log.see("end")

    def _clear_log(self) -> None:
        self.log.delete("1.0", "end")

    def _set_status(self, s: str) -> None:
        self.status_text.set(s)

    def _pick_in_file(self) -> None:
        p = filedialog.askopenfilename(title="选择 .trayitem", filetypes=[("Trayitem", "*.trayitem"), ("All", "*")])
        if p:
            self.in_path.set(p)

    def _pick_in_dir(self) -> None:
        p = filedialog.askdirectory(title="选择包含 .trayitem 的文件夹")
        if p:
            self.in_path.set(p)

    def _pick_ref(self) -> None:
        p = filedialog.askopenfilename(title="选择参考 .trayitem", filetypes=[("Trayitem", "*.trayitem"), ("All", "*")])
        if p:
            self.ref_path.set(p)

    def _pick_out(self) -> None:
        p = filedialog.askdirectory(title="选择输出目录")
        if p:
            self.out_path.set(p)

    def _open_out(self) -> None:
        p = self.out_path.get().strip()
        if p:
            open_path(p)

    def _detect_ref(self) -> None:
        ref_s = self.ref_path.get().strip()
        if not ref_s:
            messagebox.showerror("缺少参考文件", "请先选择一个参考 .trayitem 文件。")
            return
        try:
            info = service.detect_reference(Path(ref_s))
            self.detected_version.set(f"0x{info.version_value:08X}")
            self.detected_path.set(str(info.path))
            self._log(f"[检测] 版本=0x{info.version_value:08X}  路径={info.path}")
        except Exception as e:
            messagebox.showerror("检测失败", str(e))

    # ---------- worker ----------
    def _start(self) -> None:
        if self.stop_event.is_set():
            self.stop_event.clear()
        t = threading.Thread(target=self._worker, daemon=True)
        t.start()

    def _stop(self) -> None:
        self.stop_event.set()
        self._set_status("正在停止…")
        self._log("[控制] 已请求停止（会在当前文件处理完后停止）。")

    def _worker(self) -> None:
        try:
            inp_s = self.in_path.get().strip()
            if not inp_s:
                self._ui_error("缺少输入", "请选择一个 .trayitem 文件或文件夹。")
                return
            inp = Path(inp_s)

            out_s = self.out_path.get().strip() or "downgraded_tray"
            out_dir = Path(out_s)
            out_dir.mkdir(parents=True, exist_ok=True)

            manual = self.manual_version.get().strip()
            ref_s = self.ref_path.get().strip()

            target_version = None
            ref_path = None
            ref_wire = None

            if manual:
                try:
                    target_version = service.parse_hex_version(manual)
                    self._post_log(f"[配置] 使用手动版本号：0x{target_version:08X}")
                except Exception as e:
                    self._ui_error("版本号格式不正确", str(e))
                    return
            else:
                if not ref_s:
                    self._ui_error("缺少版本来源", "请提供参考 .trayitem 或手动输入版本号。")
                    return
                info = service.detect_reference(Path(ref_s))
                target_version = info.version_value
                ref_path = info.path
                ref_wire = info.wire_type
                self._post_log(f"[配置] 使用参考版本号：0x{target_version:08X}  路径={ref_path}")

            trayitems = service.collect_trayitems(inp, bool(self.recursive.get()))
            if not trayitems:
                self._ui_error("未找到文件", "输入位置未找到任何 .trayitem 文件。")
                return

            # progress init
            self.win.after(0, lambda: self.progress.configure(maximum=len(trayitems), value=0))
            self.win.after(0, lambda: self._set_status(f"0 / {len(trayitems)}"))

            def on_progress(done: int, total: int) -> None:
                def _upd():
                    self.progress.configure(value=done)
                    self._set_status(f"{done} / {total}")
                self.win.after(0, _upd)

            def on_log(msg: str) -> None:
                self._post_log(msg)

            res = service.convert_batch(
                inp=inp,
                out_dir=out_dir,
                target_version=target_version,
                ref_path=ref_path,
                ref_wire=ref_wire,
                recursive=bool(self.recursive.get()),
                copy_associated=bool(self.copy_associated.get()),
                overwrite=bool(self.overwrite.get()),
                dry_run=bool(self.dry_run.get()),
                workers=int(self.workers.get()),
                stop_event=self.stop_event,
                on_progress=on_progress,
                on_log=on_log,
            )

            if self.stop_event.is_set():
                self._post_log("[结束] 已停止。")
                self.win.after(0, lambda: self._set_status("已停止"))
            else:
                self._post_log(
                    f"[完成] 总数={res.total}  修改={res.patched}  无需修改={res.same}  跳过={res.skipped}  错误={res.errors}"
                )
                self._post_log(f"[输出] {out_dir}")
                self._post_log("建议：把输出文件复制回 Tray 后，删除一次 localthumbcache.package。")
                self.win.after(0, lambda: self._set_status("完成"))

        except Exception as e:
            self._post_log("[致命错误] " + str(e))
            self.win.after(0, lambda: self._set_status("致命错误"))

    def _post_log(self, msg: str) -> None:
        self.win.after(0, lambda: self._log(msg))

    def _ui_error(self, title: str, msg: str) -> None:
        self.win.after(0, lambda: messagebox.showerror(title, msg))

    def on_close(self) -> None:
        # save settings
        try:
            self.cfg.set(CFG_PREFIX + "geometry", self.win.geometry())
            self.cfg.set(CFG_PREFIX + "in_path", self.in_path.get())
            self.cfg.set(CFG_PREFIX + "ref_path", self.ref_path.get())
            self.cfg.set(CFG_PREFIX + "out_path", self.out_path.get())
            self.cfg.set(CFG_PREFIX + "manual_version", self.manual_version.get())
            self.cfg.set(CFG_PREFIX + "copy_associated", bool(self.copy_associated.get()))
            self.cfg.set(CFG_PREFIX + "overwrite", bool(self.overwrite.get()))
            self.cfg.set(CFG_PREFIX + "dry_run", bool(self.dry_run.get()))
            self.cfg.set(CFG_PREFIX + "recursive", bool(self.recursive.get()))
            self.cfg.set(CFG_PREFIX + "workers", int(self.workers.get()))
            self.cfg.save()
        finally:
            self.win.destroy()


def open_window(root: tk.Tk, cfg) -> None:
    TrayConverterWindow(root, cfg)
