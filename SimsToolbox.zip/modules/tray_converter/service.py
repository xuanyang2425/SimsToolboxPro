from __future__ import annotations

"""Tray 版本转换器（降版本号）- 业务逻辑

说明
- 仅负责解析/定位/修改 .trayitem 内的版本门槛字段，并可选复制同组关联文件。
- UI 层应在单独线程调用 convert_batch，并使用回调把日志/进度送回主线程。

实现来源：根据你提供的《SIMSTray版本转换器.py》整理与拆分。
"""

import dataclasses
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple


# =========================
# Protobuf-like primitives
# =========================

class ProtoParseError(Exception):
    pass


def read_varint(buf: bytes, pos: int, limit: int) -> Tuple[int, int, bytes]:
    """读取 protobuf 风格 varint。返回 (value, new_pos, raw_bytes)。"""
    result = 0
    shift = 0
    start = pos
    while pos < limit and shift <= 63:
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if (b & 0x80) == 0:
            return result, pos, buf[start:pos]
        shift += 7
    raise ProtoParseError("varint 非法或数据被截断")


def encode_varint(value: int) -> bytes:
    if value < 0:
        raise ValueError("不支持负数 varint")
    out = bytearray()
    while True:
        to_write = value & 0x7F
        value >>= 7
        if value:
            out.append(to_write | 0x80)
        else:
            out.append(to_write)
            break
    return bytes(out)


@dataclasses.dataclass
class Field:
    field_number: int
    wire_type: int
    occurrence_index: int
    key_raw: bytes
    len_raw: bytes
    value_raw: bytes
    children: Optional["Message"] = None

    def as_int(self) -> Optional[int]:
        if self.wire_type == 0:
            v, _, _ = read_varint(self.value_raw, 0, len(self.value_raw))
            return v
        if self.wire_type == 5 and len(self.value_raw) == 4:
            return int.from_bytes(self.value_raw, "little", signed=False)
        if self.wire_type == 1 and len(self.value_raw) == 8:
            return int.from_bytes(self.value_raw, "little", signed=False)
        return None


@dataclasses.dataclass
class Message:
    raw: bytes
    fields: List[Field]


def try_parse_message(raw: bytes, max_fields: int = 1500, max_depth: int = 30, _depth: int = 0) -> Optional[Message]:
    """尽力解析（best-effort）。如果无法完整解析则返回 None。"""
    if _depth > max_depth:
        return None

    pos = 0
    limit = len(raw)
    fields: List[Field] = []
    counts: Dict[int, int] = {}

    try:
        while pos < limit:
            key, pos, key_raw = read_varint(raw, pos, limit)
            if key == 0:
                return None
            field_number = key >> 3
            wire_type = key & 0x07
            if field_number == 0:
                return None

            occ = counts.get(field_number, 0)
            counts[field_number] = occ + 1

            if wire_type == 0:  # varint
                _, pos2, val_raw = read_varint(raw, pos, limit)
                pos = pos2
                f = Field(field_number, wire_type, occ, key_raw, b"", val_raw)
            elif wire_type == 1:  # 64-bit
                if pos + 8 > limit:
                    return None
                val_raw = raw[pos:pos + 8]
                pos += 8
                f = Field(field_number, wire_type, occ, key_raw, b"", val_raw)
            elif wire_type == 5:  # 32-bit
                if pos + 4 > limit:
                    return None
                val_raw = raw[pos:pos + 4]
                pos += 4
                f = Field(field_number, wire_type, occ, key_raw, b"", val_raw)
            elif wire_type == 2:  # length-delimited
                length, pos2, len_raw = read_varint(raw, pos, limit)
                pos = pos2
                if pos + length > limit:
                    return None
                val_raw = raw[pos:pos + length]
                pos += length
                f = Field(field_number, wire_type, occ, key_raw, len_raw, val_raw)
                child = try_parse_message(val_raw, max_fields=max_fields, max_depth=max_depth, _depth=_depth + 1)
                if child is not None and child.fields:
                    f.children = child
            else:
                return None

            fields.append(f)
            if len(fields) > max_fields:
                return None

        return Message(raw=raw, fields=fields)
    except ProtoParseError:
        return None


# =========================
# .trayitem header split
# =========================

@dataclasses.dataclass
class TrayPayload:
    header: bytes
    payload: bytes
    payload_offset: int


def split_tray_header(data: bytes) -> TrayPayload:
    """许多 .trayitem 文件开头包含 8 bytes header，然后才是 payload。"""
    if len(data) >= 8:
        a = int.from_bytes(data[0:4], "little", signed=False)
        b = int.from_bytes(data[4:8], "little", signed=False)
        if a == 0 and (b == len(data) - 8 or b == len(data) - 4 or b == len(data)):
            return TrayPayload(header=data[:8], payload=data[8:], payload_offset=8)
    return TrayPayload(header=b"", payload=data, payload_offset=0)


# =========================
# Version locate & patch
# =========================

PathSegment = Tuple[int, int]            # (field_number, occurrence_index)
FieldPath = Tuple[PathSegment, ...]


@dataclasses.dataclass
class VersionLocator:
    version_value: int
    wire_type: int
    path: FieldPath


def iter_fields_with_paths(msg: Message, base_path: FieldPath = ()) -> List[Tuple[Field, FieldPath]]:
    out: List[Tuple[Field, FieldPath]] = []
    for f in msg.fields:
        seg = (f.field_number, f.occurrence_index)
        path = base_path + (seg,)
        out.append((f, path))
        if f.wire_type == 2 and f.children is not None:
            out.extend(iter_fields_with_paths(f.children, path))
    return out


def guess_version_locator(msg: Message) -> Optional[VersionLocator]:
    """经验范围：版本门槛多为 0x2000..0x5000 的整数；取范围内最大值（更深路径优先）。"""
    candidates: List[Tuple[int, int, FieldPath]] = []
    for f, path in iter_fields_with_paths(msg):
        val = f.as_int()
        if val is None:
            continue
        if 0x2000 <= val <= 0x5000:
            candidates.append((val, f.wire_type, path))
    if not candidates:
        return None
    candidates.sort(key=lambda t: (t[0], len(t[2])), reverse=True)
    v, w, p = candidates[0]
    return VersionLocator(version_value=v, wire_type=w, path=p)


def locate_field_by_path(msg: Message, path: FieldPath) -> Optional[Field]:
    cur = msg
    fld: Optional[Field] = None
    for (fn, occ) in path:
        matches = [f for f in cur.fields if f.field_number == fn]
        if len(matches) <= occ:
            return None
        fld = matches[occ]
        if (fn, occ) != path[-1]:
            if fld.wire_type != 2 or fld.children is None:
                return None
            cur = fld.children
    return fld


def patch_version(msg: Message, locator: VersionLocator, new_version: int) -> Tuple[bytes, bool, Optional[int]]:
    """重建 message bytes，仅替换目标字段。返回 (new_bytes, changed, old_value)。"""
    target = locator.path

    def rebuild(cur: Message, base: FieldPath) -> Tuple[bytes, bool, Optional[int]]:
        out = bytearray()
        changed_any = False
        old_found: Optional[int] = None

        for f in cur.fields:
            seg = (f.field_number, f.occurrence_index)
            path = base + (seg,)

            if path == target:
                old_found = f.as_int()
                if f.wire_type == 0:
                    out.extend(f.key_raw)
                    out.extend(encode_varint(new_version))
                    changed_any = changed_any or (old_found != new_version)
                elif f.wire_type == 5:
                    out.extend(f.key_raw)
                    out.extend(int(new_version).to_bytes(4, "little", signed=False))
                    changed_any = changed_any or (old_found != new_version)
                else:
                    # 不认识的类型：保持原样
                    out.extend(f.key_raw)
                    if f.wire_type == 2:
                        out.extend(f.len_raw)
                    out.extend(f.value_raw)
                continue

            if f.wire_type == 2 and f.children is not None:
                child_bytes, child_changed, child_old = rebuild(f.children, path)
                if child_changed:
                    changed_any = True
                    if old_found is None and child_old is not None:
                        old_found = child_old
                out.extend(f.key_raw)
                out.extend(encode_varint(len(child_bytes)))
                out.extend(child_bytes)
            else:
                out.extend(f.key_raw)
                if f.wire_type == 2:
                    out.extend(f.len_raw)
                out.extend(f.value_raw)

        return bytes(out), changed_any, old_found

    return rebuild(msg, ())


def parse_trayitem(path: Path) -> Tuple[TrayPayload, Message, VersionLocator]:
    data = path.read_bytes()
    tp = split_tray_header(data)
    msg = try_parse_message(tp.payload)
    if msg is None:
        raise ValueError(f"无法解析 protobuf payload：{path}")
    loc = guess_version_locator(msg)
    if loc is None:
        raise ValueError(f"无法在该文件中猜测版本字段：{path}")
    return tp, msg, loc


def parse_hex_version(s: str) -> int:
    ss = s.strip().lower()
    if ss.startswith("0x"):
        ss = ss[2:]
    if len(ss) != 8 or any(c not in "0123456789abcdef" for c in ss):
        raise ValueError("版本号必须是 8 位十六进制，例如：00002BC0")
    return int(ss, 16)


def collect_trayitems(inp: Path, recursive: bool) -> List[Path]:
    if inp.is_file():
        return [inp] if inp.suffix.lower() == ".trayitem" else []
    if recursive:
        return sorted([p for p in inp.rglob("*.trayitem") if p.is_file()])
    return sorted([p for p in inp.glob("*.trayitem") if p.is_file()])


def tray_group_id(file_name: str) -> Optional[str]:
    # 例：0x00000001!0x004215edd6910135.trayitem -> "0x004215edd6910135"
    if "!" not in file_name:
        return None
    try:
        tail = file_name.split("!", 1)[1]
        base = tail.rsplit(".", 1)[0]
        return base
    except Exception:
        return None


def find_associated_files(trayitem: Path) -> List[Path]:
    gid = tray_group_id(trayitem.name)
    if not gid:
        return []
    return sorted([p for p in trayitem.parent.glob(f"*!{gid}.*") if p.is_file()])


# =========================
# Public API
# =========================

@dataclasses.dataclass
class ConvertOptions:
    recursive: bool = True
    copy_associated: bool = True
    overwrite: bool = False
    dry_run: bool = False
    workers: int = 4


@dataclasses.dataclass
class ConvertResult:
    total: int = 0
    patched: int = 0
    same: int = 0
    skipped: int = 0
    errors: int = 0
    stopped: bool = False


def detect_from_reference(ref_trayitem: Path) -> Tuple[int, FieldPath, int]:
    """返回 (target_version, field_path, wire_type)。"""
    _, _, loc = parse_trayitem(ref_trayitem)
    return loc.version_value, loc.path, loc.wire_type


def convert_batch(
    inp: Path,
    out_dir: Path,
    target_version: int,
    options: ConvertOptions,
    ref_path: Optional[FieldPath] = None,
    ref_wire_type: Optional[int] = None,
    stop_flag=None,
    on_log: Optional[Callable[[str], None]] = None,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> ConvertResult:
    """批量处理 trayitem。UI 请在后台线程调用。

    - stop_flag: threading.Event 之类，若 is_set() 为 True 则尽快停止。
    - on_log: 日志回调
    - on_progress: 进度回调 (done, total)
    """
    def log(msg: str) -> None:
        if on_log:
            on_log(msg)

    out_dir.mkdir(parents=True, exist_ok=True)

    trayitems = collect_trayitems(inp, options.recursive)
    res = ConvertResult(total=len(trayitems))
    if res.total == 0:
        log("[错误] 输入位置未找到任何 .trayitem 文件。")
        return res

    if on_progress:
        on_progress(0, res.total)

    workers = max(1, min(16, int(options.workers)))

    def should_stop() -> bool:
        return bool(stop_flag is not None and getattr(stop_flag, "is_set")() )

    def process_one(tray: Path):
        if should_stop():
            return ("stopped", tray, None)
        try:
            data = tray.read_bytes()
            tp = split_tray_header(data)
            msg = try_parse_message(tp.payload)
            if msg is None:
                return ("skip", tray, "无法解析 payload")

            locator: Optional[VersionLocator] = None
            if ref_path is not None and ref_wire_type is not None:
                if locate_field_by_path(msg, ref_path) is not None:
                    locator = VersionLocator(version_value=target_version, wire_type=ref_wire_type, path=ref_path)

            if locator is None:
                g = guess_version_locator(msg)
                if g is None:
                    return ("skip", tray, "无法定位版本字段")
                locator = g

            new_payload, changed, old_val = patch_version(msg, locator, target_version)
            out_tray = out_dir / tray.name

            if not options.dry_run:
                if out_tray.exists() and not options.overwrite:
                    return ("skip", tray, f"输出已存在：{out_tray.name}（可勾选覆盖）")

                out_tray.write_bytes(tp.header + (new_payload if changed else tp.payload))

                if options.copy_associated:
                    for f in find_associated_files(tray):
                        if f.name == tray.name:
                            continue
                        dst = out_dir / f.name
                        if dst.exists() and not options.overwrite:
                            continue
                        try:
                            dst.write_bytes(f.read_bytes())
                        except Exception:
                            pass

            if changed:
                oldv = old_val if old_val is not None else 0
                return ("patch", tray, f"0x{oldv:08X} -> 0x{target_version:08X}  路径={locator.path}")
            return ("same", tray, f"已是 0x{target_version:08X}")

        except Exception as e:
            return ("err", tray, str(e))

    done = 0

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futures = {ex.submit(process_one, t): t for t in trayitems}
        for fut in as_completed(futures):
            kind, tray, info = fut.result()

            if kind == "stopped":
                res.stopped = True
                break

            done += 1
            if kind == "patch":
                res.patched += 1
                log(f"[修改] {tray.name}  {info}")
            elif kind == "same":
                res.same += 1
                log(f"[无需修改] {tray.name}  {info}")
            elif kind == "skip":
                res.skipped += 1
                log(f"[跳过] {tray.name}  {info}")
            else:
                res.errors += 1
                log(f"[错误] {tray.name}  {info}")

            if on_progress:
                on_progress(done, res.total)

            if should_stop():
                res.stopped = True
                break

    if res.stopped:
        log("[结束] 已停止。")
    else:
        log(f"[完成] 总数={res.total}  修改={res.patched}  无需修改={res.same}  跳过={res.skipped}  错误={res.errors}")
        log(f"[输出] {out_dir}")
        log("建议：把输出文件复制回 Tray 后，删除一次 localthumbcache.package。")

    return res
