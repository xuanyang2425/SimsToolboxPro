from __future__ import annotations

import json
import os
import queue
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import urlparse

import requests
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk

from .db import DownloadRecord, TSRDatabase
from .tsr_parsers import (
    extract_first_url,
    extract_item_id,
    is_tsr_url,
    parse_tsr_details,
)


def _parse_content_disposition_filename(cd: str | None) -> str | None:
    """Parse filename from Content-Disposition header.

    Supports both filename= and RFC5987 filename*=UTF-8''... form.
    """
    if not cd:
        return None
    cd_l = cd
    # Prefer filename* (RFC 5987)
    try:
        parts = [p.strip() for p in cd_l.split(';')]
        for p in parts:
            if p.lower().startswith('filename*='):
                v = p.split('=', 1)[1].strip()
                # e.g. UTF-8''PS_MouthCorners03.package
                if "''" in v:
                    v = v.split("''", 1)[1]
                v = v.strip('"')
                from urllib.parse import unquote

                v = unquote(v)
                return v or None
    except Exception:
        pass
    # Fallback to filename=
    try:
        if 'filename=' in cd_l:
            v = cd_l.split('filename=', 1)[1].strip()
            # Strip optional quotes and trailing params
            if ';' in v:
                v = v.split(';', 1)[0].strip()
            v = v.strip('"')
            return v or None
    except Exception:
        pass
    return None


APP_TITLE = "TSR 批量下载工具 (带数据库/依赖链接)"


def _warn_python_version() -> None:
    """Best-effort warning for Windows users on very new Python versions.

    Playwright/greenlet wheels are often not published for pre-release
    Python versions (e.g. 3.14), which will break the visible-browser
    login feature unless the user installs MSVC Build Tools.
    """
    try:
        if sys.version_info >= (3, 14):
            print(
                "[WARN] 你正在使用 Python %d.%d：Playwright/greenlet 在 Windows 上可能没有预编译包，\n"
                "       如需『可见浏览器登录』，建议改用 Python 3.12/3.13 创建 venv 再安装 requirements-full.txt。"
                % (sys.version_info.major, sys.version_info.minor)
            )
    except Exception:
        pass


def _utcnow_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def _domain(url: str) -> str:
    try:
        return urlparse(url).netloc.lower()
    except Exception:
        return ""


@dataclass
class QueueItem:
    url: str
    domain: str
    item_id: int | None
    status: str = "queued"  # queued / downloading / done / skipped / failed / manual
    title: str | None = None
    creator: str | None = None
    published: str | None = None
    file_name: str | None = None
    error: str | None = None
    retry_count: int = 0
    max_retries: int = 2


class CookieJar:
    """Load Playwright cookies.json into requests.Session."""

    @staticmethod
    def load_into_session(session: requests.Session, cookies_path: str) -> bool:
        if not cookies_path or not os.path.exists(cookies_path):
            return False
        try:
            with open(cookies_path, "r", encoding="utf-8") as f:
                cookies = json.load(f)
            # Playwright storageState may be {"cookies":[...]}
            if isinstance(cookies, dict) and "cookies" in cookies:
                cookies = cookies["cookies"]
            for c in cookies:
                name = c.get("name")
                value = c.get("value")
                domain = c.get("domain")
                path = c.get("path", "/")
                if not name or value is None or not domain:
                    continue
                session.cookies.set(name, value, domain=domain, path=path)
            return True
        except Exception:
            return False


class TSRGuiApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1200x760")

        self.session = requests.Session()
        # Use a browser-like UA; helps avoid some 500/403 edge cases.
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/122.0.0.0 Safari/537.36"
                )
            }
        )

        self.download_dir_var = tk.StringVar(value=os.path.abspath("downloads"))
        self.db_path_var = tk.StringVar(value=os.path.abspath("tsr_downloads.db"))
        self.cookies_path_var = tk.StringVar(value=os.path.abspath("cookies.json"))

        self.db = TSRDatabase(self.db_path_var.get())

        self.queue_items: dict[str, QueueItem] = {}
        self.tree_id_by_url: dict[str, str] = {}

        self._stop_flag = threading.Event()
        self._work_q: queue.Queue[str] = queue.Queue()
        self._ui_q: queue.Queue[tuple[str, dict]] = queue.Queue()

        # Visible browser login (Playwright) control
        self._pw_export_event: threading.Event | None = None
        self._pw_stop_event: threading.Event | None = None
        self._pw_thread: threading.Thread | None = None

        self._build_ui()
        self._start_background_threads()

    def _hydrate_from_db(self, qi: QueueItem) -> bool:
        """Fill queue item fields from DB if present.

        This is used:
        - immediately after adding to queue
        - after status updates / downloads

        Returns True if anything changed.
        """
        changed = False
        try:
            rec = self.db.get_download(qi.url)
        except Exception:
            rec = None

        if rec:
            # status
            if rec.status == "downloaded":
                if qi.status not in {"downloading"}:
                    qi.status = "done"
                    changed = True
            elif rec.status == "skipped_exists":
                if qi.status != "downloading":
                    qi.status = "skipped"
                    changed = True
            elif rec.status == "failed":
                if qi.status != "downloading":
                    qi.status = "failed"
                    changed = True

            # file name
            if rec.file_name and qi.file_name != rec.file_name:
                qi.file_name = rec.file_name
                changed = True
            if rec.error and qi.error != rec.error:
                qi.error = rec.error
                changed = True

        if qi.item_id:
            try:
                meta = self.db.get_meta(qi.item_id)
            except Exception:
                meta = None
            if meta:
                if meta.title and qi.title != meta.title:
                    qi.title = meta.title
                    changed = True
                if meta.creator and qi.creator != meta.creator:
                    qi.creator = meta.creator
                    changed = True
                if meta.publish_date and qi.published != meta.publish_date:
                    qi.published = meta.publish_date
                    changed = True

        return changed

    # ---------------- UI ----------------
    def _build_ui(self) -> None:
        top = ttk.Frame(self.root)
        top.pack(fill=tk.X, padx=10, pady=10)

        # Settings row
        ttk.Label(top, text="下载目录").grid(row=0, column=0, sticky="w")
        ttk.Entry(top, textvariable=self.download_dir_var, width=55).grid(row=0, column=1, sticky="we", padx=6)
        ttk.Button(top, text="选择…", command=self._choose_download_dir).grid(row=0, column=2, padx=4)

        ttk.Label(top, text="数据库").grid(row=0, column=3, sticky="w", padx=(18, 0))
        ttk.Entry(top, textvariable=self.db_path_var, width=40).grid(row=0, column=4, sticky="we", padx=6)
        ttk.Button(top, text="打开数据库列表", command=self._open_db_viewer).grid(row=0, column=5, padx=4)

        # Cookies row
        ttk.Label(top, text="cookies.json").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(top, textvariable=self.cookies_path_var, width=55).grid(
            row=1, column=1, sticky="we", padx=6, pady=(8, 0)
        )
        ttk.Button(top, text="导入 cookies", command=self._load_cookies).grid(row=1, column=2, padx=4, pady=(8, 0))
        ttk.Button(top, text="可见浏览器登录", command=self._launch_visible_login).grid(
            row=1, column=3, padx=(18, 0), pady=(8, 0)
        )
        self.login_status = ttk.Label(top, text="未导入登录 cookies")
        self.login_status.grid(row=1, column=4, sticky="w", pady=(8, 0))

        top.columnconfigure(1, weight=1)
        top.columnconfigure(4, weight=1)

        mid = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
        mid.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        # Input + queue
        upper = ttk.Frame(mid)
        mid.add(upper, weight=3)

        input_frame = ttk.Labelframe(upper, text="粘贴链接列表 (支持 'URL | 标题' 格式；自动忽略无关内容)")
        input_frame.pack(fill=tk.X, pady=(0, 8))
        self.input_text = tk.Text(input_frame, height=6)
        self.input_text.pack(fill=tk.X, padx=8, pady=8)
        btns = ttk.Frame(input_frame)
        btns.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Button(btns, text="添加到队列", command=self._add_from_input).pack(side=tk.LEFT)
        ttk.Button(btns, text="清空输入", command=lambda: self.input_text.delete("1.0", tk.END)).pack(side=tk.LEFT, padx=6)
        ttk.Button(btns, text="开始下载", command=self._start_download).pack(side=tk.LEFT, padx=16)
        ttk.Button(btns, text="停止", command=self._stop_download).pack(side=tk.LEFT, padx=6)
        ttk.Button(btns, text="补全元信息(所选)", command=self._fetch_meta_selected).pack(side=tk.LEFT, padx=16)
        ttk.Button(btns, text="打开所选链接", command=self._open_selected_urls).pack(side=tk.LEFT, padx=6)
        ttk.Button(btns, text="重试失败(所选)", command=self._retry_failed_selected).pack(side=tk.LEFT, padx=16)
        ttk.Button(btns, text="重试全部失败", command=self._retry_all_failed).pack(side=tk.LEFT, padx=6)
        ttk.Button(btns, text="清空队列", command=self._clear_queue).pack(side=tk.LEFT, padx=16)

        # Queue table
        queue_frame = ttk.Labelframe(upper, text="下载队列")
        queue_frame.pack(fill=tk.BOTH, expand=True)
        cols = ("status", "title", "creator", "published", "url", "file")
        self.tree = ttk.Treeview(queue_frame, columns=cols, show="headings", height=12)
        self.tree.heading("status", text="状态")
        self.tree.heading("title", text="标题")
        self.tree.heading("creator", text="作者")
        self.tree.heading("published", text="发布时间")
        self.tree.heading("url", text="URL")
        self.tree.heading("file", text="文件")
        self.tree.column("status", width=90, anchor="w")
        self.tree.column("title", width=220, anchor="w")
        self.tree.column("creator", width=120, anchor="w")
        self.tree.column("published", width=140, anchor="w")
        self.tree.column("url", width=440, anchor="w")
        self.tree.column("file", width=160, anchor="w")
        self.tree.tag_configure("external", foreground="#cc0000")
        self.tree.tag_configure("skipped", foreground="#888888")
        self.tree.tag_configure("done", foreground="#555555")
        self.tree.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.tree.bind("<<TreeviewSelect>>", self._on_select_item)
        self.tree.bind("<Double-1>", self._on_double_click)
        self.tree.bind("<Button-3>", self._on_queue_right_click)

        self._queue_menu = tk.Menu(self.root, tearoff=0)
        self._queue_menu.add_command(label="复制 URL", command=self._menu_copy_url)
        self._queue_menu.add_command(label="复制作者", command=self._menu_copy_creator)
        self._queue_menu.add_command(label="复制文件名", command=self._menu_copy_file)
        self._queue_menu.add_separator()
        self._queue_menu.add_command(label="打开链接", command=self._menu_open_url)
        self._queue_menu.add_command(label="打开本地文件", command=self._menu_open_local_file)
        self._queue_menu.add_separator()
        self._queue_menu.add_command(label="重试此项", command=self._menu_retry_item)

        # Details + logs
        lower = ttk.Frame(mid)
        mid.add(lower, weight=2)

        bottom_pane = ttk.PanedWindow(lower, orient=tk.HORIZONTAL)
        bottom_pane.pack(fill=tk.BOTH, expand=True)

        req_frame = ttk.Labelframe(bottom_pane, text="依赖/外部链接 (Required!)")
        bottom_pane.add(req_frame, weight=1)
        self.req_list = ttk.Treeview(req_frame, columns=("group", "title", "url"), show="headings", height=8)
        self.req_list.heading("group", text="分组")
        self.req_list.heading("title", text="标题")
        self.req_list.heading("url", text="链接")
        self.req_list.column("group", width=200, anchor="w")
        self.req_list.column("title", width=240, anchor="w")
        self.req_list.column("url", width=420, anchor="w")
        self.req_list.tag_configure("external", foreground="#cc0000")
        self.req_list.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        self.req_list.bind("<Double-1>", self._open_selected_required)
        self.req_list.bind("<Button-3>", self._on_required_right_click)

        self._req_menu = tk.Menu(self.root, tearoff=0)
        self._req_menu.add_command(label="复制链接", command=self._menu_copy_required_url)
        self._req_menu.add_command(label="打开链接", command=self._open_selected_required)
        self._req_menu.add_separator()
        self._req_menu.add_command(label="打开所有外部依赖", command=self._open_all_external_required)
        req_btns = ttk.Frame(req_frame)
        req_btns.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Button(req_btns, text="打开所选依赖", command=self._open_selected_required).pack(side=tk.LEFT)
        ttk.Button(req_btns, text="打开所有外部依赖", command=self._open_all_external_required).pack(side=tk.LEFT, padx=6)

        log_frame = ttk.Labelframe(bottom_pane, text="日志")
        bottom_pane.add(log_frame, weight=1)
        self.log_text = tk.Text(log_frame, height=8)
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)

    def _log(self, msg: str) -> None:
        ts = time.strftime("%H:%M:%S")
        self.log_text.insert(tk.END, f"[{ts}] {msg}\n")
        self.log_text.see(tk.END)

    # ---------------- actions ----------------
    def _choose_download_dir(self) -> None:
        d = filedialog.askdirectory(initialdir=self.download_dir_var.get())
        if d:
            self.download_dir_var.set(d)

    def _load_cookies(self) -> None:
        path = filedialog.askopenfilename(
            title="选择 cookies.json",
            filetypes=[("JSON", "*.json"), ("All", "*")],
            initialdir=os.path.dirname(self.cookies_path_var.get()) or ".",
        )
        if not path:
            return
        self.cookies_path_var.set(path)
        ok = CookieJar.load_into_session(self.session, path)
        self.login_status.config(text="已导入登录 cookies" if ok else "导入失败")
        self._log("已导入 cookies" if ok else "导入 cookies 失败：请确认文件格式")

    def _launch_visible_login(self) -> None:
        """Launch a visible browser (Playwright) to let user login.

        We do NOT bypass any captcha / protections. This simply helps you login
        normally and export cookies.json for subsequent requests.
        """
        # Prevent launching multiple visible browsers at once.
        if self._pw_thread and self._pw_thread.is_alive():
            messagebox.showinfo("登录", "可见浏览器登录已在运行中。\n\n请完成浏览器登录后回到软件导出 cookies。")
            return

        try:
            from playwright.sync_api import sync_playwright
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
        except Exception:
            messagebox.showerror(
                "缺少 Playwright",
                "未检测到 playwright。请先执行：\n\n  pip install playwright\n  playwright install chromium\n\n然后重试。",
            )
            return

        cookies_path = self.cookies_path_var.get() or os.path.abspath("cookies.json")
        self.cookies_path_var.set(cookies_path)

        self._pw_export_event = threading.Event()
        self._pw_stop_event = threading.Event()

        def _run_visible_login():
            """Run Playwright entirely in this worker thread.

            IMPORTANT: Do NOT pass Playwright objects (context/page/browser) back to Tk thread.
            Tk thread will only signal export/stop via Events.
            """

            self._ui_q.put(("log", {"msg": "Launching visible browser for login (Playwright)..."}))
            try:
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=False)
                    context = browser.new_context()
                    page = context.new_page()

                    # TSR sometimes keeps connections open; waiting for full 'load' can hang.
                    # Use domcontentloaded and a longer timeout.
                    try:
                        page.goto(
                            "https://www.thesimsresource.com/",
                            wait_until="domcontentloaded",
                            timeout=120000,
                        )
                    except PlaywrightTimeoutError:
                        # Still proceed; user can manually refresh.
                        self._ui_q.put(("log", {"msg": "打开 TSR 首页超时（120s）。浏览器已打开，请手动刷新/输入网址后登录。"}))
                    except Exception as e:
                        self._ui_q.put(("log", {"msg": f"打开 TSR 首页失败：{e}"}))

                    # Ask user to login and confirm in the app.
                    self._ui_q.put(
                        (
                            "login_prompt",
                            {
                                "text": "浏览器已打开。请在浏览器里正常登录 TSR。\n\n登录完成后，回到软件点击“确定”以导出 cookies。",
                                "cookies_path": cookies_path,
                            },
                        )
                    )

                    # Wait for export or stop
                    while True:
                        if self._pw_stop_event and self._pw_stop_event.is_set():
                            break
                        if self._pw_export_event and self._pw_export_event.wait(0.2):
                            break

                    if self._pw_stop_event and self._pw_stop_event.is_set():
                        self._ui_q.put(("log", {"msg": "已取消导出 cookies。"}))
                    else:
                        try:
                            # Export cookies to file inside Playwright thread BEFORE shutting down.
                            context.storage_state(path=cookies_path)
                            ok = CookieJar.load_into_session(self.session, cookies_path)
                            self._ui_q.put(("cookies_exported", {"ok": ok, "path": cookies_path}))
                        except Exception as e:
                            self._ui_q.put(("cookies_export_failed", {"error": str(e)}))

                    try:
                        context.close()
                    except Exception:
                        pass
                    try:
                        browser.close()
                    except Exception:
                        pass
            except Exception as e:
                self._ui_q.put(("cookies_export_failed", {"error": f"Playwright 运行失败：{e}"}))

        self._pw_thread = threading.Thread(target=_run_visible_login, daemon=True)
        self._pw_thread.start()

    def _add_from_input(self) -> None:
        text = self.input_text.get("1.0", tk.END)
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        added = 0
        ignored = 0
        for line in lines:
            url = extract_first_url(line)
            if not url:
                ignored += 1
                continue
            # Ignore shop root or browse listing pages unless it contains item id
            item_id = extract_item_id(url)
            if is_tsr_url(url) and not item_id:
                ignored += 1
                continue

            if url in self.queue_items:
                continue

            domain = _domain(url)
            is_tsr = is_tsr_url(url)
            qi = QueueItem(
                url=url,
                domain=domain,
                item_id=item_id if is_tsr else None,
                status="queued" if is_tsr else "manual",
            )

            # Hydrate from DB immediately (show title/author/publish/file if we already have them).
            self._hydrate_from_db(qi)

            self.queue_items[url] = qi
            self._insert_or_update_tree(qi)
            added += 1

            # Persist basic record early so the database becomes a "link ledger".
            # IMPORTANT: don't downgrade existing records (e.g. downloaded -> queued).
            try:
                existing = self.db.get_download(url)
                if existing is None:
                    self.db.upsert_download(
                        DownloadRecord(
                            url=url,
                            domain=domain,
                            item_id=qi.item_id,
                            status=("manual_external" if qi.status == "manual" else "queued"),
                            downloaded_at=_utcnow_iso(),
                        )
                    )
                else:
                    # Only补全缺失字段（例如 item_id），不改现有状态/时间。
                    if existing.item_id is None and qi.item_id is not None:
                        self.db.upsert_download(
                            DownloadRecord(
                                url=url,
                                domain=domain,
                                item_id=qi.item_id,
                                status=existing.status,
                                downloaded_at=None,
                            )
                        )
            except Exception:
                pass

            # Prefetch meta in background for TSR items
            if qi.item_id and qi.status not in {"skipped", "done"}:
                threading.Thread(target=self._fetch_meta_for_url, args=(url,), daemon=True).start()

        self._log(f"添加 {added} 条；忽略 {ignored} 条（非下载页面/无效行）")

    def _insert_or_update_tree(self, qi: QueueItem) -> None:
        vals = (
            qi.status,
            qi.title or "",
            qi.creator or "",
            qi.published or "",
            qi.url,
            qi.file_name or "",
        )
        tags = []
        if qi.status == "manual" or (qi.domain and not qi.domain.endswith("thesimsresource.com")):
            tags.append("external")
        if qi.status == "skipped":
            tags.append("skipped")
        if qi.status == "done":
            tags.append("done")

        if qi.url in self.tree_id_by_url:
            iid = self.tree_id_by_url[qi.url]
            self.tree.item(iid, values=vals, tags=tags)
        else:
            iid = self.tree.insert("", tk.END, values=vals, tags=tags)
            self.tree_id_by_url[qi.url] = iid

    def _start_download(self) -> None:
        os.makedirs(self.download_dir_var.get(), exist_ok=True)
        # enqueue TSR items only
        n = 0
        for url, qi in list(self.queue_items.items()):
            if qi.status in {"queued"} and qi.item_id:
                self._work_q.put(url)
                n += 1
        self._log(f"开始下载：已入队 {n} 个 TSR 链接")

    def _stop_download(self) -> None:
        self._stop_flag.set()
        self._log("已请求停止（正在下载的任务会尽快结束）")

    def _fetch_meta_selected(self) -> None:
        sels = self.tree.selection()
        if not sels:
            return
        for iid in sels:
            vals = self.tree.item(iid, "values")
            if not vals:
                continue
            url = vals[4]
            qi = self.queue_items.get(url)
            if qi and qi.item_id:
                threading.Thread(target=self._fetch_meta_for_url, args=(url,), daemon=True).start()
        self._log("已提交元信息补全任务")

    def _open_selected_urls(self) -> None:
        sels = self.tree.selection()
        if not sels:
            return
        for iid in sels:
            vals = self.tree.item(iid, "values")
            if vals:
                webbrowser.open(vals[4])

    def _retry_failed_selected(self) -> None:
        sels = self.tree.selection()
        if not sels:
            return
        n = 0
        for iid in sels:
            vals = self.tree.item(iid, "values")
            if not vals:
                continue
            url = vals[4]
            qi = self.queue_items.get(url)
            if not qi or not qi.item_id:
                continue
            if qi.status not in {"failed"}:
                continue
            qi.status = "queued"
            qi.error = None
            qi.retry_count = 0
            self._insert_or_update_tree(qi)
            self._work_q.put(url)
            n += 1
        self._log(f"已重试 {n} 个失败任务")

    def _retry_all_failed(self) -> None:
        n = 0
        for url, qi in list(self.queue_items.items()):
            if qi.item_id and qi.status == "failed":
                qi.status = "queued"
                qi.error = None
                qi.retry_count = 0
                self._insert_or_update_tree(qi)
                self._work_q.put(url)
                n += 1
        self._log(f"已重试全部失败任务：{n} 个")

    def _clear_queue(self) -> None:
        # Don't clear while downloading unless user confirms.
        busy = any(q.status in {"queued", "downloading"} for q in self.queue_items.values())
        if busy:
            if not messagebox.askyesno("确认", "队列中仍有任务在排队/下载中。仍然清空队列吗？\n\n(不会删除数据库与已下载文件)"):
                return

        self.queue_items.clear()
        self.tree_id_by_url.clear()
        for x in self.tree.get_children():
            self.tree.delete(x)
        for x in self.req_list.get_children():
            self.req_list.delete(x)
        self._log("已清空当前队列")

    # ---------------- selection / required ----------------
    def _on_select_item(self, _evt=None) -> None:
        sels = self.tree.selection()
        if not sels:
            return
        iid = sels[0]
        vals = self.tree.item(iid, "values")
        if not vals:
            return
        url = vals[4]
        qi = self.queue_items.get(url)
        self._render_required_for(qi.item_id if qi else None)

    def _render_required_for(self, item_id: int | None) -> None:
        for x in self.req_list.get_children():
            self.req_list.delete(x)
        if not item_id:
            return
        links = self.db.list_required_links(item_id)
        for l in links:
            tags = []
            if not is_tsr_url(l.req_url):
                tags.append("external")
            self.req_list.insert("", tk.END, values=(l.req_group or "", l.req_title or "", l.req_url), tags=tags)

    def _open_selected_required(self, _evt=None) -> None:
        sels = self.req_list.selection()
        if not sels:
            return
        for iid in sels:
            vals = self.req_list.item(iid, "values")
            if vals:
                webbrowser.open(vals[2])

    def _open_all_external_required(self) -> None:
        urls = []
        for iid in self.req_list.get_children():
            vals = self.req_list.item(iid, "values")
            if not vals:
                continue
            u = vals[2]
            if u and not is_tsr_url(u):
                urls.append(u)
        if not urls:
            messagebox.showinfo("提示", "没有外部依赖链接")
            return
        if len(urls) > 15:
            if not messagebox.askyesno("确认", f"将打开 {len(urls)} 个外部链接，是否继续？"):
                return
        for u in urls:
            webbrowser.open(u)

    def _on_double_click(self, evt=None) -> None:
        """Double click: copy the clicked cell content.

        For convenience:
        - Ctrl + double click will open the URL (same as the button).
        """
        if evt is None:
            return
        rowid = self.tree.identify_row(evt.y)
        colid = self.tree.identify_column(evt.x)  # '#1'..'#N'
        if not rowid or not colid:
            return
        vals = self.tree.item(rowid, "values")
        if not vals:
            return
        try:
            idx = int(colid.lstrip("#")) - 1
        except Exception:
            idx = -1
        if idx < 0 or idx >= len(vals):
            return

        value = str(vals[idx]) if vals[idx] is not None else ""

        # Ctrl + double click -> open URL
        # Tk state bit 0x0004 is typically Control on Windows.
        if (evt.state & 0x0004) and len(vals) >= 5:
            webbrowser.open(vals[4])
            return

        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(value)
            self._log(f"已复制：{value[:120]}" + ("..." if len(value) > 120 else ""))
        except Exception:
            pass

    # ---------------- context menu ----------------
    def _on_queue_right_click(self, evt=None) -> None:
        if evt is None:
            return
        rowid = self.tree.identify_row(evt.y)
        if rowid:
            try:
                self.tree.selection_set(rowid)
            except Exception:
                pass
        try:
            self._queue_menu.tk_popup(evt.x_root, evt.y_root)
        finally:
            try:
                self._queue_menu.grab_release()
            except Exception:
                pass

    def _sel_queue_values(self):
        sels = self.tree.selection()
        if not sels:
            return None
        vals = self.tree.item(sels[0], "values")
        return vals or None

    def _copy_to_clipboard(self, txt: str) -> None:
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(txt)
        except Exception:
            pass

    def _menu_copy_url(self) -> None:
        vals = self._sel_queue_values()
        if not vals:
            return
        url = str(vals[4]) if len(vals) > 4 else ""
        self._copy_to_clipboard(url)
        self._log(f"已复制 URL：{url[:120]}" + ("..." if len(url) > 120 else ""))

    def _menu_copy_creator(self) -> None:
        vals = self._sel_queue_values()
        if not vals:
            return
        creator = str(vals[2]) if len(vals) > 2 else ""
        self._copy_to_clipboard(creator)
        self._log(f"已复制作者：{creator}")

    def _menu_copy_file(self) -> None:
        vals = self._sel_queue_values()
        if not vals:
            return
        fname = str(vals[5]) if len(vals) > 5 else ""
        self._copy_to_clipboard(fname)
        self._log(f"已复制文件名：{fname}")

    def _menu_open_url(self) -> None:
        vals = self._sel_queue_values()
        if not vals:
            return
        url = str(vals[4]) if len(vals) > 4 else ""
        if url:
            webbrowser.open(url)

    def _menu_open_local_file(self) -> None:
        vals = self._sel_queue_values()
        if not vals:
            return
        url = str(vals[4]) if len(vals) > 4 else ""
        qi = self.queue_items.get(url)
        if not qi:
            return
        if not qi.file_name:
            return
        path = os.path.join(self.download_dir_var.get(), qi.file_name)
        if not os.path.exists(path):
            messagebox.showinfo("提示", "本地文件不存在（可能尚未下载完成）。")
            return
        try:
            os.startfile(path)  # type: ignore[attr-defined]
        except Exception:
            try:
                webbrowser.open(path)
            except Exception:
                pass

    def _menu_retry_item(self) -> None:
        vals = self._sel_queue_values()
        if not vals:
            return
        url = str(vals[4]) if len(vals) > 4 else ""
        qi = self.queue_items.get(url)
        if not qi:
            return
        if qi.status not in {"failed", "skipped"}:
            # allow retry even if queued, but don't duplicate
            pass
        qi.status = "queued"
        qi.error = None
        qi.retry_count = 0
        self._insert_or_update_tree(qi)

    def _on_required_right_click(self, evt=None) -> None:
        if evt is None:
            return
        rowid = self.req_list.identify_row(evt.y)
        if rowid:
            try:
                self.req_list.selection_set(rowid)
            except Exception:
                pass
        try:
            self._req_menu.tk_popup(evt.x_root, evt.y_root)
        finally:
            try:
                self._req_menu.grab_release()
            except Exception:
                pass

    def _menu_copy_required_url(self) -> None:
        sels = self.req_list.selection()
        if not sels:
            return
        vals = self.req_list.item(sels[0], "values")
        if not vals or len(vals) < 3:
            return
        u = str(vals[2])
        self._copy_to_clipboard(u)
        self._log(f"已复制依赖链接：{u[:120]}" + ("..." if len(u) > 120 else ""))

    # ---------------- meta fetching ----------------
    def _fetch_meta_for_url(self, url: str) -> None:
        qi = self.queue_items.get(url)
        if not qi or not qi.item_id:
            return
        item_id = qi.item_id

        # Skip if already fetched recently
        meta0 = self.db.get_meta(item_id)
        if meta0 and meta0.title and meta0.last_meta_fetch:
            return

        try:
            r = self.session.get(url, timeout=25)
            if r.status_code != 200:
                raise RuntimeError(f"HTTP {r.status_code}")
            meta, required = parse_tsr_details(r.text, url)
            if meta:
                meta.last_meta_fetch = _utcnow_iso()
                self.db.upsert_meta(meta)
                if required:
                    self.db.replace_required_links(item_id, required)
                self._ui_q.put(
                    (
                        "meta_ok",
                        {
                            "url": url,
                            "title": meta.title,
                            "creator": meta.creator,
                            "published": (meta.publish_date or "")[:10] if (meta.publish_date or "").startswith("20") else meta.publish_date,
                        },
                    )
                )
        except Exception as e:
            self._ui_q.put(("log", {"msg": f"元信息获取失败({item_id}): {e}"}))

    # ---------------- downloader worker ----------------
    def _download_worker(self) -> None:
        while True:
            url = self._work_q.get()
            if url is None:
                return
            if self._stop_flag.is_set():
                self._ui_q.put(("log", {"msg": "停止标志已设置：跳过剩余队列"}))
                # drain quickly
                while not self._work_q.empty():
                    try:
                        self._work_q.get_nowait()
                    except Exception:
                        break
                self._stop_flag.clear()

            qi = self.queue_items.get(url)
            if not qi or not qi.item_id:
                continue
            if qi.status == "skipped":
                continue

            self._ui_q.put(("status", {"url": url, "status": "downloading"}))

            # NOTE:
            # The original upstream project uses a captcha-based initDownload.
            # This GUI focuses on organizing links + metadata + dependencies.
            # If you have a valid TSR session (VIP or normal login cookies),
            # you can still download via the standard file endpoint.
            def _retryable_status(code: int) -> bool:
                return code in {408, 425, 429, 500, 502, 503, 504}

            def _retryable_error(err: Exception) -> bool:
                try:
                    import requests as _rq

                    if isinstance(err, (_rq.exceptions.Timeout, _rq.exceptions.ConnectionError, _rq.exceptions.ChunkedEncodingError)):
                        return True
                except Exception:
                    pass
                msg = str(err).lower()
                if "timeout" in msg or "timed out" in msg or "temporarily" in msg:
                    return True
                if "http 5" in msg or "http 50" in msg:
                    return True
                if "429" in msg:
                    return True
                return False

            last_error: str | None = None
            ok = False
            for attempt in range(max(1, qi.max_retries + 1)):
                if self._stop_flag.is_set():
                    last_error = "stopped"
                    break

                if attempt > 0:
                    qi.retry_count = attempt
                    backoff = min(8 * attempt, 30)
                    self._ui_q.put(("log", {"msg": f"下载重试 {attempt}/{qi.max_retries}：{qi.item_id}，{backoff}s 后重试…"}))
                    time.sleep(backoff)

                try:
                    # Try direct file download endpoint that usually redirects
                    # to a signed URL when the session is valid.
                    download_url = f"https://www.thesimsresource.com/downloads/download/itemId/{qi.item_id}"
                    with self.session.get(download_url, stream=True, timeout=90, allow_redirects=True) as resp:
                        if resp.status_code != 200:
                            # Retry on transient codes.
                            if _retryable_status(resp.status_code):
                                raise RuntimeError(f"download HTTP {resp.status_code}")
                            raise RuntimeError(f"download HTTP {resp.status_code}")

                        # File name
                        cd = resp.headers.get("Content-Disposition")
                        fname = _parse_content_disposition_filename(cd)
                        if not fname:
                            fname = f"{qi.item_id}.package"

                        dest = os.path.join(self.download_dir_var.get(), fname)
                        if os.path.exists(dest):
                            self._ui_q.put(("status", {"url": url, "status": "skipped", "file": fname}))
                            self.db.upsert_download(
                                DownloadRecord(
                                    url=url,
                                    domain=qi.domain,
                                    item_id=qi.item_id,
                                    file_name=fname,
                                    file_path=dest,
                                    file_size=os.path.getsize(dest),
                                    status="skipped_exists",
                                    downloaded_at=_utcnow_iso(),
                                )
                            )
                            ok = True
                            break

                        # Stream write
                        total = 0
                        with open(dest, "wb") as f:
                            for chunk in resp.iter_content(chunk_size=1024 * 128):
                                if self._stop_flag.is_set():
                                    raise RuntimeError("stopped")
                                if chunk:
                                    f.write(chunk)
                                    total += len(chunk)

                        self.db.upsert_download(
                            DownloadRecord(
                                url=url,
                                domain=qi.domain,
                                item_id=qi.item_id,
                                file_name=fname,
                                file_path=dest,
                                file_size=total,
                                status="downloaded",
                                downloaded_at=_utcnow_iso(),
                            )
                        )
                        self._ui_q.put(("status", {"url": url, "status": "done", "file": fname}))
                        ok = True
                        break
                except Exception as e:
                    last_error = str(e)
                    # Stop is not retryable
                    if "stopped" in last_error.lower() or self._stop_flag.is_set():
                        break
                    if attempt < qi.max_retries and _retryable_error(e):
                        continue
                    break

            if not ok:
                err = last_error or "unknown error"
                self.db.upsert_download(
                    DownloadRecord(
                        url=url,
                        domain=qi.domain,
                        item_id=qi.item_id,
                        status="failed",
                        error=err,
                        downloaded_at=_utcnow_iso(),
                    )
                )
                self._ui_q.put(("status", {"url": url, "status": "failed", "error": err}))

    def _start_background_threads(self) -> None:
        threading.Thread(target=self._download_worker, daemon=True).start()
        self._poll_ui_queue()

    def _poll_ui_queue(self) -> None:
        try:
            while True:
                kind, payload = self._ui_q.get_nowait()
                if kind == "log":
                    self._log(payload.get("msg", ""))
                elif kind == "status":
                    url = payload["url"]
                    qi = self.queue_items.get(url)
                    if not qi:
                        continue
                    qi.status = payload.get("status", qi.status)
                    if payload.get("file"):
                        qi.file_name = payload["file"]
                    if payload.get("error"):
                        qi.error = payload["error"]
                    # If DB already has meta/file,补全显示。
                    try:
                        self._hydrate_from_db(qi)
                    except Exception:
                        pass
                    self._insert_or_update_tree(qi)
                elif kind == "meta_ok":
                    url = payload["url"]
                    qi = self.queue_items.get(url)
                    if not qi:
                        continue
                    qi.title = payload.get("title")
                    qi.creator = payload.get("creator")
                    qi.published = payload.get("published")
                    self._insert_or_update_tree(qi)
                    # refresh required panel if this is selected
                    sels = self.tree.selection()
                    if sels:
                        vals = self.tree.item(sels[0], "values")
                        if vals and vals[4] == url:
                            self._render_required_for(qi.item_id)
                elif kind == "login_prompt":
                    # User confirms login is done; signal worker thread to export.
                    if messagebox.askokcancel("登录", payload.get("text", "已登录？")):
                        if self._pw_export_event:
                            self._pw_export_event.set()
                    else:
                        if self._pw_stop_event:
                            self._pw_stop_event.set()

                elif kind == "cookies_exported":
                    ok = bool(payload.get("ok"))
                    self.login_status.config(text="已导入登录 cookies" if ok else "导出/导入失败")
                    self._log("已导出并导入 cookies" if ok else "导出 cookies 成功，但导入失败")

                elif kind == "cookies_export_failed":
                    err = payload.get("error", "未知错误")
                    self.login_status.config(text="导出 cookies 失败")
                    self._log(f"导出 cookies 失败：{err}")
                else:
                    pass
        except queue.Empty:
            pass
        self.root.after(120, self._poll_ui_queue)

    # ---------------- DB viewer ----------------
    def _open_db_viewer(self) -> None:
        # Re-open DB with possibly new path
        try:
            self.db.close()
        except Exception:
            pass
        self.db = TSRDatabase(self.db_path_var.get())

        win = tk.Toplevel(self.root)
        win.title("数据库列表")
        win.geometry("1200x650")

        top = ttk.Frame(win)
        top.pack(fill=tk.X, padx=10, pady=10)
        kw = tk.StringVar(value="")
        ttk.Label(top, text="搜索").pack(side=tk.LEFT)
        ent = ttk.Entry(top, textvariable=kw, width=40)
        ent.pack(side=tk.LEFT, padx=6)

        cols = ("status", "title", "creator", "published", "tags", "file", "size", "url")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        for c, t in zip(cols, ["状态", "标题", "作者", "发布时间", "分类/标签", "文件", "大小", "URL"], strict=True):
            tree.heading(c, text=t)
        tree.column("status", width=90)
        tree.column("title", width=240)
        tree.column("creator", width=120)
        tree.column("published", width=160)
        tree.column("tags", width=240)
        tree.column("file", width=180)
        tree.column("size", width=80)
        tree.column("url", width=460)
        tree.tag_configure("external", foreground="#cc0000")
        tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))

        detail = ttk.Labelframe(win, text="依赖/外部链接")
        detail.pack(fill=tk.BOTH, expand=False, padx=10, pady=(0, 10))
        req = ttk.Treeview(detail, columns=("group", "title", "url"), show="headings", height=6)
        req.heading("group", text="分组")
        req.heading("title", text="标题")
        req.heading("url", text="链接")
        req.column("group", width=220)
        req.column("title", width=260)
        req.column("url", width=660)
        req.tag_configure("external", foreground="#cc0000")
        req.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        req.bind("<Double-1>", lambda _e: self._open_req_tree(req))

        btns = ttk.Frame(detail)
        btns.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Button(btns, text="打开所选依赖", command=lambda: self._open_req_tree(req)).pack(side=tk.LEFT)
        ttk.Button(btns, text="打开所有外部依赖", command=lambda: self._open_all_external_req_tree(req)).pack(
            side=tk.LEFT, padx=6
        )

        state = {"rows": []}

        def refresh():
            for x in tree.get_children():
                tree.delete(x)
            state["rows"] = self.db.search_records(kw.get(), limit=2000)
            for r in state["rows"]:
                tags = " / ".join((r.get("tags") or [])[:8])
                if r.get("tags") and len(r["tags"]) > 8:
                    tags += " …"
                size = r.get("file_size") or ""
                vals = (
                    r.get("status") or "",
                    r.get("title") or "",
                    r.get("creator") or "",
                    r.get("publish_date") or "",
                    tags,
                    r.get("file_name") or "",
                    size,
                    r.get("url") or "",
                )
                row_tags = []
                if r.get("domain") and not str(r.get("domain")).endswith("thesimsresource.com"):
                    row_tags.append("external")
                tree.insert("", tk.END, values=vals, tags=row_tags)

        def on_select(_evt=None):
            for x in req.get_children():
                req.delete(x)
            sel = tree.selection()
            if not sel:
                return
            vals = tree.item(sel[0], "values")
            url = vals[7]
            rec = self.db.get_download(url)
            if not rec or not rec.item_id:
                return
            links = self.db.list_required_links(rec.item_id)
            for l in links:
                row_tags = []
                if not is_tsr_url(l.req_url):
                    row_tags.append("external")
                req.insert("", tk.END, values=(l.req_group or "", l.req_title or "", l.req_url), tags=row_tags)

        def on_enter(_evt=None):
            refresh()

        ent.bind("<Return>", on_enter)
        tree.bind("<<TreeviewSelect>>", on_select)
        refresh()

    def _open_req_tree(self, req_tree: ttk.Treeview) -> None:
        sels = req_tree.selection()
        if not sels:
            return
        for iid in sels:
            vals = req_tree.item(iid, "values")
            if vals:
                webbrowser.open(vals[2])

    def _open_all_external_req_tree(self, req_tree: ttk.Treeview) -> None:
        urls = []
        for iid in req_tree.get_children():
            vals = req_tree.item(iid, "values")
            if not vals:
                continue
            u = vals[2]
            if u and not is_tsr_url(u):
                urls.append(u)
        if not urls:
            messagebox.showinfo("提示", "没有外部依赖链接")
            return
        if len(urls) > 15:
            if not messagebox.askyesno("确认", f"将打开 {len(urls)} 个外部链接，是否继续？"):
                return
        for u in urls:
            webbrowser.open(u)


def main() -> None:
    _warn_python_version()
    root = tk.Tk()
    app = TSRGuiApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
