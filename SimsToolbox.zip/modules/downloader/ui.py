from __future__ import annotations

import os
import tkinter as tk

from .db import TSRDatabase
from .gui_app import TSRGuiApp, CookieJar


def _safe_set_geometry(win: tk.Toplevel, geo: str | None) -> None:
    if not geo:
        return
    try:
        win.geometry(geo)
    except Exception:
        pass


def open_window(root: tk.Misc, cfg) -> None:
    """Open TSR Downloader window.

    `cfg` is the shared ConfigStore from the toolbox.
    This function restores basic settings and saves them on close.
    """

    win = tk.Toplevel(root)
    win.title("下载器 · The Sims Resource")

    # Restore geometry
    _safe_set_geometry(win, cfg.get("downloader.window_geometry"))

    # Create the downloader UI
    app = TSRGuiApp(win)

    # Restore paths
    download_dir = cfg.get("downloader.download_dir")
    if isinstance(download_dir, str) and download_dir.strip():
        app.download_dir_var.set(download_dir.strip())

    db_path = cfg.get("downloader.db_path")
    if isinstance(db_path, str) and db_path.strip():
        app.db_path_var.set(db_path.strip())
        try:
            app.db.close()
        except Exception:
            pass
        try:
            app.db = TSRDatabase(app.db_path_var.get())
        except Exception:
            pass

    cookies_path = cfg.get("downloader.cookies_path")
    if isinstance(cookies_path, str) and cookies_path.strip():
        app.cookies_path_var.set(cookies_path.strip())

    # Auto import cookies if present
    try:
        cpath = app.cookies_path_var.get().strip()
        if cpath and os.path.exists(cpath):
            ok = CookieJar.load_into_session(app.session, cpath)
            try:
                app.login_status.config(text="已导入登录 cookies" if ok else "未导入登录 cookies")
            except Exception:
                pass
    except Exception:
        pass

    def _on_close() -> None:
        # Stop active downloads before exiting
        try:
            app._stop_download()
        except Exception:
            pass

        try:
            cfg.set("downloader.window_geometry", win.geometry())
            cfg.set("downloader.download_dir", app.download_dir_var.get())
            cfg.set("downloader.db_path", app.db_path_var.get())
            cfg.set("downloader.cookies_path", app.cookies_path_var.get())

            cfg.append_history("downloader.download_dir_history", app.download_dir_var.get())
            cfg.append_history("downloader.db_path_history", app.db_path_var.get())
            cfg.append_history("downloader.cookies_path_history", app.cookies_path_var.get())

            cfg.save()
        except Exception:
            pass

        try:
            app.db.close()
        except Exception:
            pass

        win.destroy()

    win.protocol("WM_DELETE_WINDOW", _on_close)
