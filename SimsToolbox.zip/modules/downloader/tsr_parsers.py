from __future__ import annotations

import html as _html
import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

from bs4 import BeautifulSoup

from .db import ModMeta, RequiredLink


PRIMARY_CATEGORIES = {
    # From TSR 'Categories' menu (一级分类)
    "Featured Creations",
    "Accessories",
    "Clothing",
    "Eye Colors",
    "Facial Hair",
    "Floors",
    "Hairstyles",
    "Lots",
    "Makeup",
    "Maxis Match",
    "Mods",
    "Objects",
    "Pets",
    "Roofs",
    "Rooms",
    "Sets",
    "Shoes",
    "Sims",
    "Skintones",
    "Terrain paints",
    "Walls",
}


def _norm_space(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def extract_first_url(line: str) -> Optional[str]:
    m = re.search(r"https?://\S+", line.strip())
    if not m:
        return None
    url = m.group(0)
    # Strip trailing punctuation that copy tools sometimes include
    url = url.rstrip("\",'\")").rstrip(".,””]")
    return url


def is_tsr_url(url: str) -> bool:
    try:
        host = urlparse(url).netloc.lower()
    except Exception:
        return False
    return host.endswith("thesimsresource.com")


def extract_item_id(url: str) -> Optional[int]:
    # Supports:
    # - https://www.thesimsresource.com/downloads/1758388
    # - https://www.thesimsresource.com/downloads/details/.../id/1758388/
    m = re.search(r"/id/(\d+)(?:/|$)", url)
    if m:
        return int(m.group(1))
    m = re.search(r"/downloads/(\d+)(?:/|$)", url)
    if m:
        return int(m.group(1))
    return None


def _epoch_to_iso(epoch_s: str | int | None) -> Optional[str]:
    if epoch_s is None:
        return None
    try:
        epoch = int(epoch_s)
        if epoch <= 0:
            return None
        dt = datetime.fromtimestamp(epoch, tz=timezone.utc)
        return dt.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    except Exception:
        return None


def _decode_data_item_attr(data_item: str) -> dict:
    # data-item is HTML-escaped and sometimes includes unicode escapes.
    raw = _html.unescape(data_item)
    return json.loads(raw)


def extract_item_json_from_html(html_text: str, item_id: int) -> Optional[dict]:
    soup = BeautifulSoup(html_text, "html.parser")
    for el in soup.select(".item-wrapper[data-item]"):
        val = el.get("data-item")
        if not val:
            continue
        try:
            obj = _decode_data_item_attr(val)
        except Exception:
            continue
        # Some pages use 'ID' as string.
        if str(obj.get("ID")) == str(item_id) or str(obj.get("ItemID")) == str(item_id):
            return obj
    # Fallback: regex search for the one matching ID
    m = re.search(r"data-item=\"(?P<json>\{[^\"]*?\"ID\"\s*:\s*\"%s\"[^\"]*?\})\"" % item_id, html_text)
    if m:
        try:
            return _decode_data_item_attr(m.group("json"))
        except Exception:
            return None
    return None


def extract_category_tags_from_breadcrumbs(html_text: str) -> list[str]:
    soup = BeautifulSoup(html_text, "html.parser")
    tags: list[str] = []
    # Details page breadcrumbs
    for a in soup.select(".full-category-path a"):
        t = _norm_space(a.get_text())
        if t:
            tags.append(t)
    # Browse cards (when details page not available)
    if not tags:
        cat = soup.select_one(".browse-info-category")
        if cat:
            parts = [_norm_space(p) for p in cat.get_text().split("/")]
            tags.extend([p for p in parts if p])
    # Unique preserve order
    seen = set()
    out: list[str] = []
    for t in tags:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def flatten_tags(categories: list[str]) -> list[str]:
    # categories may include values like "Sims 4 / Sets / Hair" or "Sims"
    parts: list[str] = []
    for c in categories:
        if not c:
            continue
        if "/" in c:
            for p in c.split("/"):
                p = _norm_space(p)
                if p:
                    parts.append(p)
        else:
            parts.append(_norm_space(c))
    # Unique preserve order
    seen = set()
    out: list[str] = []
    for p in parts:
        if p and p not in seen:
            seen.add(p)
            out.append(p)
    return out


def parse_tsr_details(html_text: str, url: str) -> tuple[Optional[ModMeta], list[RequiredLink]]:
    """Parse a TSR details page HTML.

    Returns (ModMeta|None, required_links[]).
    """
    item_id = extract_item_id(url)
    if not item_id:
        return None, []

    obj = extract_item_json_from_html(html_text, item_id)
    soup = BeautifulSoup(html_text, "html.parser")

    # Creator info (fallback to HTML)
    creator = None
    creator_url = None
    a = soup.select_one(".created-by-wrapper .artist-name a")
    if a:
        creator = _norm_space(a.get_text())
        creator_url = a.get("href")
    if obj:
        creator = creator or obj.get("creatorName") or obj.get("creator")
        # minisiteName/minisitePath help build profile URL
        if not creator_url and obj.get("minisitePath") and obj.get("minisiteName"):
            creator_url = f"/{obj.get('minisitePath')}/{obj.get('minisiteName')}/"

    title = None
    if obj:
        title = obj.get("title")
    if not title:
        h = soup.select_one("h1")
        title = _norm_space(h.get_text()) if h else None

    publish_date = None
    file_size_bytes = None
    game = None
    category_slug = None
    categories_raw: list[str] = []

    if obj:
        game = obj.get("game")
        category_slug = obj.get("PrimaryCategory") or obj.get("category")
        publish_date = _epoch_to_iso(obj.get("publishDate")) or _epoch_to_iso(obj.get("lastUpdated"))
        try:
            file_size_bytes = int(obj.get("FileSize") or obj.get("filesize") or 0) or None
        except Exception:
            file_size_bytes = None

        # CategoryDisplay is like "Sims 4 / Young Adult"
        if obj.get("CategoryDisplay"):
            categories_raw.append(_norm_space(str(obj.get("CategoryDisplay"))))
        # 'type' might be 'sims', treat as primary category
        if obj.get("type"):
            categories_raw.append(str(obj.get("type")).strip())
        # Some pages have 'Categories' list
        for c in obj.get("Categories") or []:
            name = c.get("Name")
            if name:
                categories_raw.append(_norm_space(name))

    # Breadcrumb tags are more complete: Sims 4 / Sims / Female / Young Adult
    breadcrumb_tags = extract_category_tags_from_breadcrumbs(html_text)
    categories_raw.extend(breadcrumb_tags)

    # Normalize & unique categories_raw
    seen = set()
    categories: list[str] = []
    for c in categories_raw:
        c = _norm_space(str(c))
        if not c:
            continue
        if c not in seen:
            seen.add(c)
            categories.append(c)

    tags = flatten_tags(categories)
    # Add a best-effort primary category tag, matching TSR menu names
    # e.g. type='sims' -> 'Sims'
    if obj and obj.get("type"):
        t = str(obj.get("type")).strip().lower()
        if t == "sims":
            tags.insert(0, "Sims")
        elif t == "sets":
            tags.insert(0, "Sets")

    # Dedup tags, keep order
    seen = set()
    tags_out: list[str] = []
    for t in tags:
        tt = _norm_space(t)
        if not tt:
            continue
        # Fix common cases
        if tt.lower() == "sims4":
            tt = "Sims 4"
        # Capitalize menu-like tokens when possible
        if tt.lower() in {"sims", "sets", "mods", "objects", "makeup"}:
            tt = tt.capitalize()
        if tt not in seen:
            seen.add(tt)
            tags_out.append(tt)

    meta = ModMeta(
        item_id=item_id,
        title=title,
        creator=creator,
        creator_url=creator_url,
        publish_date=publish_date,
        categories=categories,
        tags=tags_out,
        category_slug=category_slug,
        game=game,
        file_size_bytes=file_size_bytes,
    )

    required_links: list[RequiredLink] = []
    if obj and obj.get("requiredDownloads"):
        for group in obj.get("requiredDownloads") or []:
            group_name = _norm_space(group.get("group") or group.get("originalName") or "") or None
            for d in group.get("downloads") or []:
                dl = d.get("download")
                if not dl:
                    continue
                title2 = _norm_space(d.get("title") or "") or None
                tp = (d.get("type") or "").lower()
                if tp == "id":
                    try:
                        req_id = int(dl)
                    except Exception:
                        continue
                    req_url = f"https://www.thesimsresource.com/downloads/{req_id}"
                    required_links.append(
                        RequiredLink(
                            owner_item_id=item_id,
                            req_url=req_url,
                            req_title=title2,
                            req_group=group_name,
                            is_tsr=True,
                            req_item_id=req_id,
                        )
                    )
                else:
                    # External link
                    req_url = str(dl)
                    required_links.append(
                        RequiredLink(
                            owner_item_id=item_id,
                            req_url=req_url,
                            req_title=title2,
                            req_group=group_name,
                            is_tsr=is_tsr_url(req_url),
                            req_item_id=extract_item_id(req_url) if is_tsr_url(req_url) else None,
                        )
                    )

    return meta, required_links
