from __future__ import annotations

import json
import os
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Iterable, Optional


def _utcnow_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


@dataclass
class DownloadRecord:
    url: str
    domain: str
    item_id: Optional[int] = None
    file_name: Optional[str] = None
    file_path: Optional[str] = None
    file_size: Optional[int] = None
    sha256: Optional[str] = None
    status: str = "unknown"  # downloaded / skipped_exists / failed / manual_external / queued
    error: Optional[str] = None
    downloaded_at: Optional[str] = None


@dataclass
class ModMeta:
    item_id: int
    title: Optional[str] = None
    creator: Optional[str] = None
    creator_url: Optional[str] = None
    publish_date: Optional[str] = None  # ISO date or datetime
    categories: Optional[list[str]] = None  # raw categories as shown on TSR
    tags: Optional[list[str]] = None  # flattened tags
    category_slug: Optional[str] = None
    game: Optional[str] = None
    file_size_bytes: Optional[int] = None
    last_meta_fetch: Optional[str] = None


@dataclass
class RequiredLink:
    owner_item_id: int
    req_url: str
    req_title: Optional[str] = None
    req_group: Optional[str] = None
    is_tsr: bool = False
    req_item_id: Optional[int] = None


class TSRDatabase:
    """SQLite DB for downloads + metadata.

    Safe to create/open repeatedly. Performs lightweight schema migrations.
    """

    SCHEMA_VERSION = 2

    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    def _get_user_version(self) -> int:
        cur = self.conn.execute("PRAGMA user_version")
        return int(cur.fetchone()[0])

    def _set_user_version(self, v: int) -> None:
        self.conn.execute(f"PRAGMA user_version = {int(v)}")
        self.conn.commit()

    def _init_schema(self) -> None:
        v = self._get_user_version()
        if v == 0:
            self._create_schema_v2()
            self._set_user_version(self.SCHEMA_VERSION)
            return

        # Future migrations here
        if v < 2:
            self._migrate_to_v2()
            self._set_user_version(2)

    def _create_schema_v2(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS downloads (
              url TEXT PRIMARY KEY,
              domain TEXT NOT NULL,
              item_id INTEGER,
              file_name TEXT,
              file_path TEXT,
              file_size INTEGER,
              sha256 TEXT,
              status TEXT NOT NULL,
              error TEXT,
              downloaded_at TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_downloads_item_id ON downloads(item_id);
            CREATE INDEX IF NOT EXISTS idx_downloads_status ON downloads(status);

            CREATE TABLE IF NOT EXISTS mod_meta (
              item_id INTEGER PRIMARY KEY,
              title TEXT,
              creator TEXT,
              creator_url TEXT,
              publish_date TEXT,
              categories_json TEXT,
              tags_json TEXT,
              category_slug TEXT,
              game TEXT,
              file_size_bytes INTEGER,
              last_meta_fetch TEXT
            );

            CREATE TABLE IF NOT EXISTS required_links (
              owner_item_id INTEGER NOT NULL,
              req_url TEXT NOT NULL,
              req_title TEXT,
              req_group TEXT,
              is_tsr INTEGER NOT NULL,
              req_item_id INTEGER,
              PRIMARY KEY(owner_item_id, req_url)
            );

            CREATE INDEX IF NOT EXISTS idx_required_owner ON required_links(owner_item_id);
            """
        )
        self.conn.commit()

    def _migrate_to_v2(self) -> None:
        # v1 -> v2 migration placeholder (no-op for now)
        self._create_schema_v2()

    # ----------------- writes -----------------
    def upsert_download(self, rec: DownloadRecord) -> None:
        self.conn.execute(
            """
            INSERT INTO downloads(url, domain, item_id, file_name, file_path, file_size, sha256, status, error, downloaded_at)
            VALUES(?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(url) DO UPDATE SET
              domain=excluded.domain,
              item_id=COALESCE(excluded.item_id, downloads.item_id),
              file_name=COALESCE(excluded.file_name, downloads.file_name),
              file_path=COALESCE(excluded.file_path, downloads.file_path),
              file_size=COALESCE(excluded.file_size, downloads.file_size),
              sha256=COALESCE(excluded.sha256, downloads.sha256),
              status=excluded.status,
              error=excluded.error,
              downloaded_at=COALESCE(excluded.downloaded_at, downloads.downloaded_at)
            """,
            (
                rec.url,
                rec.domain,
                rec.item_id,
                rec.file_name,
                rec.file_path,
                rec.file_size,
                rec.sha256,
                rec.status,
                rec.error,
                rec.downloaded_at,
            ),
        )
        self.conn.commit()

    def upsert_meta(self, meta: ModMeta) -> None:
        self.conn.execute(
            """
            INSERT INTO mod_meta(item_id, title, creator, creator_url, publish_date, categories_json, tags_json, category_slug, game, file_size_bytes, last_meta_fetch)
            VALUES(?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(item_id) DO UPDATE SET
              title=COALESCE(excluded.title, mod_meta.title),
              creator=COALESCE(excluded.creator, mod_meta.creator),
              creator_url=COALESCE(excluded.creator_url, mod_meta.creator_url),
              publish_date=COALESCE(excluded.publish_date, mod_meta.publish_date),
              categories_json=COALESCE(excluded.categories_json, mod_meta.categories_json),
              tags_json=COALESCE(excluded.tags_json, mod_meta.tags_json),
              category_slug=COALESCE(excluded.category_slug, mod_meta.category_slug),
              game=COALESCE(excluded.game, mod_meta.game),
              file_size_bytes=COALESCE(excluded.file_size_bytes, mod_meta.file_size_bytes),
              last_meta_fetch=COALESCE(excluded.last_meta_fetch, mod_meta.last_meta_fetch)
            """,
            (
                meta.item_id,
                meta.title,
                meta.creator,
                meta.creator_url,
                meta.publish_date,
                json.dumps(meta.categories or [], ensure_ascii=False),
                json.dumps(meta.tags or [], ensure_ascii=False),
                meta.category_slug,
                meta.game,
                meta.file_size_bytes,
                meta.last_meta_fetch or _utcnow_iso(),
            ),
        )
        self.conn.commit()

    def replace_required_links(self, owner_item_id: int, links: list[RequiredLink]) -> None:
        self.conn.execute("DELETE FROM required_links WHERE owner_item_id=?", (owner_item_id,))
        self.conn.executemany(
            """
            INSERT OR REPLACE INTO required_links(owner_item_id, req_url, req_title, req_group, is_tsr, req_item_id)
            VALUES(?,?,?,?,?,?)
            """,
            [
                (
                    l.owner_item_id,
                    l.req_url,
                    l.req_title,
                    l.req_group,
                    1 if l.is_tsr else 0,
                    l.req_item_id,
                )
                for l in links
            ],
        )
        self.conn.commit()

    # ----------------- reads -----------------
    def has_url(self, url: str) -> bool:
        cur = self.conn.execute("SELECT 1 FROM downloads WHERE url=? LIMIT 1", (url,))
        return cur.fetchone() is not None

    def get_download(self, url: str) -> Optional[DownloadRecord]:
        cur = self.conn.execute("SELECT * FROM downloads WHERE url=?", (url,))
        row = cur.fetchone()
        if not row:
            return None
        return DownloadRecord(**dict(row))

    def get_meta(self, item_id: int) -> Optional[ModMeta]:
        cur = self.conn.execute("SELECT * FROM mod_meta WHERE item_id=?", (item_id,))
        row = cur.fetchone()
        if not row:
            return None
        d = dict(row)
        return ModMeta(
            item_id=d["item_id"],
            title=d.get("title"),
            creator=d.get("creator"),
            creator_url=d.get("creator_url"),
            publish_date=d.get("publish_date"),
            categories=json.loads(d.get("categories_json") or "[]"),
            tags=json.loads(d.get("tags_json") or "[]"),
            category_slug=d.get("category_slug"),
            game=d.get("game"),
            file_size_bytes=d.get("file_size_bytes"),
            last_meta_fetch=d.get("last_meta_fetch"),
        )

    def list_required_links(self, owner_item_id: int) -> list[RequiredLink]:
        cur = self.conn.execute(
            "SELECT * FROM required_links WHERE owner_item_id=? ORDER BY req_group, req_title", (owner_item_id,)
        )
        rows = cur.fetchall()
        out: list[RequiredLink] = []
        for r in rows:
            out.append(
                RequiredLink(
                    owner_item_id=r["owner_item_id"],
                    req_url=r["req_url"],
                    req_title=r["req_title"],
                    req_group=r["req_group"],
                    is_tsr=bool(r["is_tsr"]),
                    req_item_id=r["req_item_id"],
                )
            )
        return out

    def search_records(self, keyword: str = "", limit: int = 1000) -> list[dict[str, Any]]:
        kw = f"%{keyword.strip()}%" if keyword.strip() else "%"
        cur = self.conn.execute(
            """
            SELECT d.url, d.domain, d.item_id, d.file_name, d.file_path, d.file_size, d.status, d.downloaded_at,
                   m.title, m.creator, m.publish_date, m.tags_json
            FROM downloads d
            LEFT JOIN mod_meta m ON d.item_id = m.item_id
            WHERE d.url LIKE ?
               OR d.file_name LIKE ?
               OR IFNULL(m.title,'') LIKE ?
               OR IFNULL(m.creator,'') LIKE ?
               OR IFNULL(m.tags_json,'') LIKE ?
            ORDER BY COALESCE(d.downloaded_at,'') DESC
            LIMIT ?
            """,
            (kw, kw, kw, kw, kw, int(limit)),
        )
        rows = cur.fetchall()
        res: list[dict[str, Any]] = []
        for r in rows:
            d = dict(r)
            # decode tags_json for convenience
            try:
                d["tags"] = json.loads(d.get("tags_json") or "[]")
            except Exception:
                d["tags"] = []
            res.append(d)
        return res
