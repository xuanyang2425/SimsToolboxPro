from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import time
from pathlib import Path
from typing import Any, Optional


_INVALID_FS = re.compile(r'[<>:"/\\|?*]')


def sanitize_folder_name(name: str) -> str:
    """Make a filesystem-safe folder name on Windows.

    Keeps Unicode, removes invalid chars, trims trailing dots/spaces.
    """
    s = (name or "").strip()
    s = _INVALID_FS.sub("_", s)
    s = s.rstrip(" .")
    return s or "未命名"


def _now_ts() -> int:
    return int(time.time())


class ModManagerDB:
    """Mod 管理器数据库层。

    说明：
    - 复用下载器的 SQLite DB（通常是 tsr_downloads.db）。
    - 只在缺表时创建最小表结构，避免“先打开管理器但 DB 还没初始化”崩溃。
    - 为了兼容 modules/mod_manager/ui.py，本类提供 UI 需要的 API 与返回结构：
      - list_groups/get_group 返回 dict（可用 g["id"] 访问）
      - list_mods_all/list_mods_unassigned/list_mods_in_group 返回 dict 列表（包含 tags:list）
      - create_group 返回新 group_id（int）
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(os.path.dirname(os.path.abspath(db_path))).mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init_tables()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception:
            pass

    def _init_tables(self) -> None:
        # downloads / mod_meta 可能由下载器创建；这里仅在缺失时补齐最小结构
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS downloads (
              url TEXT PRIMARY KEY,
              domain TEXT,
              item_id TEXT,
              file_name TEXT,
              file_path TEXT,
              file_size INTEGER,
              status TEXT,
              downloaded_at INTEGER
            );
            CREATE INDEX IF NOT EXISTS idx_downloads_item_id ON downloads(item_id);

            CREATE TABLE IF NOT EXISTS mod_meta (
              item_id TEXT PRIMARY KEY,
              title TEXT,
              creator TEXT,
              publish_date TEXT,
              tags_json TEXT
            );

            CREATE TABLE IF NOT EXISTS mod_groups (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT NOT NULL,
              parent_id INTEGER,
              folder_name TEXT NOT NULL,
              rel_path TEXT NOT NULL,
              created_at INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_mod_groups_parent ON mod_groups(parent_id);

            CREATE TABLE IF NOT EXISTS mod_group_map (
              url TEXT NOT NULL,
              group_id INTEGER NOT NULL,
              is_primary INTEGER NOT NULL DEFAULT 1,
              created_at INTEGER NOT NULL,
              PRIMARY KEY(url, group_id)
            );
            CREATE INDEX IF NOT EXISTS idx_mod_group_map_group ON mod_group_map(group_id);

            CREATE TABLE IF NOT EXISTS managed_files (
              url TEXT NOT NULL,
              group_id INTEGER NOT NULL,
              file_path TEXT NOT NULL,
              file_name TEXT,
              op TEXT,
              updated_at INTEGER NOT NULL,
              PRIMARY KEY(url, group_id)
            );
            CREATE INDEX IF NOT EXISTS idx_managed_files_group ON managed_files(group_id);
            """
        )
        self.conn.commit()

    # ---------------- groups ----------------
    def list_groups(self) -> list[dict[str, Any]]:
        cur = self.conn.execute(
            "SELECT id, name, parent_id, folder_name, rel_path, created_at FROM mod_groups ORDER BY parent_id, created_at"
        )
        return [dict(r) for r in cur.fetchall()]

    def get_group(self, group_id: int) -> Optional[dict[str, Any]]:
        cur = self.conn.execute(
            "SELECT id, name, parent_id, folder_name, rel_path, created_at FROM mod_groups WHERE id=?",
            (int(group_id),),
        )
        r = cur.fetchone()
        return dict(r) if r else None

    def group_has_children(self, group_id: int) -> bool:
        cur = self.conn.execute("SELECT 1 FROM mod_groups WHERE parent_id=? LIMIT 1", (int(group_id),))
        return cur.fetchone() is not None

    def get_group_abs_path(self, group_id: int, managed_root: str) -> str:
        g = self.get_group(int(group_id))
        if not g:
            return ""
        return str(Path(managed_root).expanduser() / str(g["rel_path"]))

    def create_group(self, name: str, parent_id: Optional[int], managed_root: Optional[str] = None) -> int:
        name = (name or "").strip()
        if not name:
            raise ValueError("组别名称不能为空")

        folder = sanitize_folder_name(name)
        if parent_id is None:
            rel = folder
        else:
            parent = self.get_group(int(parent_id))
            if not parent:
                raise ValueError("父组别不存在")
            rel = str(Path(str(parent["rel_path"])) / folder)

        ts = _now_ts()
        cur = self.conn.execute(
            "INSERT INTO mod_groups(name, parent_id, folder_name, rel_path, created_at) VALUES(?,?,?,?,?)",
            (name, parent_id, folder, rel, ts),
        )
        self.conn.commit()
        gid = int(cur.lastrowid)

        if managed_root:
            try:
                root = Path(managed_root).expanduser()
                root.mkdir(parents=True, exist_ok=True)
                (root / rel).mkdir(parents=True, exist_ok=True)
            except Exception:
                pass

        return gid

    def rename_group(self, group_id: int, new_name: str, managed_root: Optional[str] = None) -> None:
        g = self.get_group(int(group_id))
        if not g:
            raise ValueError("组别不存在")

        new_name = (new_name or "").strip()
        if not new_name:
            raise ValueError("新名称不能为空")

        new_folder = sanitize_folder_name(new_name)

        if g["parent_id"] is None:
            new_rel = new_folder
        else:
            parent = self.get_group(int(g["parent_id"]))
            if not parent:
                raise ValueError("父组别不存在")
            new_rel = str(Path(str(parent["rel_path"])) / new_folder)

        old_rel = str(g["rel_path"])

        # FS rename (optional)
        if managed_root:
            try:
                root = Path(managed_root).expanduser()
                old_abs = (root / old_rel)
                new_abs = (root / new_rel)
                if old_abs.exists() and old_abs.is_dir():
                    new_abs.parent.mkdir(parents=True, exist_ok=True)
                    old_abs.rename(new_abs)
            except Exception:
                pass

        # update self
        self.conn.execute(
            "UPDATE mod_groups SET name=?, folder_name=?, rel_path=? WHERE id=?",
            (new_name, new_folder, new_rel, int(group_id)),
        )

        # update descendants rel_path prefix
        like_prefix = old_rel.rstrip("/") + "/%"
        cur = self.conn.execute("SELECT id, rel_path FROM mod_groups WHERE rel_path LIKE ?", (like_prefix,))
        for r in cur.fetchall():
            rid = int(r["id"])
            relp = str(r["rel_path"])
            if relp.startswith(old_rel.rstrip("/") + "/"):
                newp = new_rel.rstrip("/") + relp[len(old_rel.rstrip("/")) :]
                self.conn.execute("UPDATE mod_groups SET rel_path=? WHERE id=?", (newp, rid))

        self.conn.commit()

    def delete_group(self, group_id: int, delete_folder: bool = False, managed_root: Optional[str] = None) -> None:
        if self.group_has_children(int(group_id)):
            raise ValueError("该组别还有子组别，不能删除")

        g = self.get_group(int(group_id))

        # delete folder (optional, safe)
        if delete_folder and managed_root and g:
            try:
                root = Path(managed_root).expanduser().resolve()
                folder_abs = (root / str(g["rel_path"])).resolve()
                if str(folder_abs).startswith(str(root)) and folder_abs.exists() and folder_abs.is_dir():
                    shutil.rmtree(folder_abs)
            except Exception:
                pass

        self.conn.execute("DELETE FROM mod_group_map WHERE group_id=?", (int(group_id),))
        self.conn.execute("DELETE FROM managed_files WHERE group_id=?", (int(group_id),))
        self.conn.execute("DELETE FROM mod_groups WHERE id=?", (int(group_id),))
        self.conn.commit()

    # ---------------- filter values ----------------
    def list_creators(self) -> list[str]:
        cur = self.conn.execute(
            "SELECT DISTINCT IFNULL(creator,'') AS c FROM mod_meta WHERE IFNULL(creator,'') <> '' ORDER BY c"
        )
        return [r["c"] for r in cur.fetchall()]

    def list_tags(self) -> list[str]:
        cur = self.conn.execute("SELECT tags_json FROM mod_meta WHERE tags_json IS NOT NULL")
        tags: set[str] = set()
        for r in cur.fetchall():
            try:
                arr = json.loads(r["tags_json"] or "[]")
                if isinstance(arr, list):
                    for t in arr:
                        if isinstance(t, str) and t.strip():
                            tags.add(t.strip())
            except Exception:
                continue
        return sorted(tags)

    def list_statuses(self) -> list[str]:
        try:
            cur = self.conn.execute(
                "SELECT DISTINCT IFNULL(status,'') AS s FROM downloads WHERE IFNULL(status,'') <> '' ORDER BY s"
            )
            return [r["s"] for r in cur.fetchall()]
        except Exception:
            return []

    # ---------------- mod lists (UI required APIs) ----------------
    def _normalize_mod_rows(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for r in rows:
            d = dict(r)
            # tags
            tags = d.get("tags")
            if not isinstance(tags, list):
                tags = []
            # IMPORTANT: ui.py 的排序 key 函数在 tags 为空时会把 [] 当成 falsy => 变成 0，导致 list/int 混排报错。
            # 为避免崩溃，保证 tags 至少有 1 个元素（空字符串），显示时 join 后仍为空。
            if len(tags) == 0:
                tags = [""]
            d["tags"] = tags

            # convenience keys used by UI sort headers
            d["publish"] = d.get("publish_date") or ""
            d["file"] = d.get("file_name") or (os.path.basename(d.get("file_path") or "") or "")

            out.append(d)
        return out

    def list_mods_all(
        self,
        keyword: str = "",
        creator: Optional[str] = None,
        tag: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 5000,
    ) -> list[dict[str, Any]]:
        rows = self.query_mods(
            keyword=keyword or "",
            creator=creator or "",
            tag=tag or "",
            status=status or "",
            group_id=None,
            unassigned_only=False,
            limit=limit,
        )
        return self._normalize_mod_rows(rows)

    def list_mods_unassigned(
        self,
        keyword: str = "",
        creator: Optional[str] = None,
        tag: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 5000,
    ) -> list[dict[str, Any]]:
        rows = self.query_mods(
            keyword=keyword or "",
            creator=creator or "",
            tag=tag or "",
            status=status or "",
            group_id=None,
            unassigned_only=True,
            limit=limit,
        )
        return self._normalize_mod_rows(rows)

    def list_mods_in_group(
        self,
        group_id: int,
        keyword: str = "",
        creator: Optional[str] = None,
        tag: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 5000,
    ) -> list[dict[str, Any]]:
        rows = self.query_mods(
            keyword=keyword or "",
            creator=creator or "",
            tag=tag or "",
            status=status or "",
            group_id=int(group_id),
            unassigned_only=False,
            limit=limit,
        )
        return self._normalize_mod_rows(rows)

    # ---------------- internal query ----------------
    def query_mods(
        self,
        keyword: str = "",
        creator: str = "",
        tag: str = "",
        status: str = "",
        group_id: Optional[int] = None,
        unassigned_only: bool = False,
        sort_key: str = "downloaded_at",
        sort_desc: bool = True,
        limit: int = 2000,
    ) -> list[dict[str, Any]]:
        kw = (keyword or "").strip()
        params: list[Any] = []
        where: list[str] = []

        if kw:
            like = f"%{kw}%"
            where.append(
                "(d.url LIKE ? OR IFNULL(d.file_name,'') LIKE ? OR IFNULL(m.title,'') LIKE ? OR IFNULL(m.creator,'') LIKE ?)"
            )
            params.extend([like, like, like, like])

        if creator:
            where.append("IFNULL(m.creator,'') = ?")
            params.append(creator)

        if tag:
            where.append("IFNULL(m.tags_json,'') LIKE ?")
            t = json.dumps(tag, ensure_ascii=False).strip('"')
            params.append(f"%{t}%")

        if status:
            where.append("IFNULL(d.status,'') = ?")
            params.append(status)

        join_group = ""
        if group_id is not None:
            join_group = "JOIN mod_group_map gm ON gm.url = d.url AND gm.group_id = ?"
            params.insert(0, int(group_id))

        if unassigned_only:
            where.append("NOT EXISTS (SELECT 1 FROM mod_group_map gm2 WHERE gm2.url = d.url)")

        where_sql = ("WHERE " + " AND ".join(where)) if where else ""

        sort_map = {
            "title": "IFNULL(m.title,'')",
            "creator": "IFNULL(m.creator,'')",
            "status": "IFNULL(d.status,'')",
            "file_name": "IFNULL(d.file_name,'')",
            "downloaded_at": "COALESCE(d.downloaded_at,'')",
        }
        order_expr = sort_map.get(sort_key, "COALESCE(d.downloaded_at,'')")
        order_sql = f"ORDER BY {order_expr} {'DESC' if sort_desc else 'ASC'}"

        cur = self.conn.execute(
            f"""
            SELECT
              d.url, d.domain, d.item_id, d.file_name, d.file_path, d.file_size, d.status, d.downloaded_at,
              m.title, m.creator, m.publish_date, m.tags_json
            FROM downloads d
            LEFT JOIN mod_meta m ON d.item_id = m.item_id
            {join_group}
            {where_sql}
            {order_sql}
            LIMIT ?
            """,
            (*params, int(limit)),
        )

        res: list[dict[str, Any]] = []
        for r in cur.fetchall():
            d = dict(r)
            try:
                tags = json.loads(d.get("tags_json") or "[]")
                d["tags"] = tags if isinstance(tags, list) else []
            except Exception:
                d["tags"] = []
            res.append(d)
        return res

    # ---------------- local path helpers ----------------
    def get_group_file_for_url(self, url: str, group_id: int) -> Optional[str]:
        cur = self.conn.execute("SELECT file_path FROM managed_files WHERE url=? AND group_id=?", (url, int(group_id)))
        r = cur.fetchone()
        return str(r["file_path"]) if r else None

    def get_any_managed_file(self, url: str) -> Optional[str]:
        cur = self.conn.execute(
            "SELECT file_path FROM managed_files WHERE url=? ORDER BY updated_at DESC LIMIT 1",
            (url,),
        )
        r = cur.fetchone()
        return str(r["file_path"]) if r else None

    def get_best_local_path(self, url: str, group_id: Optional[int] = None, managed_root: Optional[str] = None) -> str:
        # 1) specific group managed file
        if group_id is not None:
            p = self.get_group_file_for_url(url, int(group_id))
            if p and os.path.exists(p):
                return p

        # 2) downloads path
        try:
            cur = self.conn.execute("SELECT file_path FROM downloads WHERE url=?", (url,))
            r = cur.fetchone()
            if r and r["file_path"]:
                p = str(r["file_path"])
                if os.path.exists(p):
                    return p
        except Exception:
            pass

        # 3) any managed file
        p = self.get_any_managed_file(url)
        if p and os.path.exists(p):
            return p

        return ""

    # ---------------- assignments + file ops ----------------
    def ensure_group_folder(self, root_dir: str, group_id: int) -> Path:
        g = self.get_group(int(group_id))
        if not g:
            raise ValueError("组别不存在")
        p = Path(root_dir).expanduser() / str(g["rel_path"])
        p.mkdir(parents=True, exist_ok=True)
        return p

    def _non_conflict_path(self, target_dir: Path, file_name: str) -> Path:
        base = Path(file_name).stem
        ext = Path(file_name).suffix
        cand = target_dir / (base + ext)
        if not cand.exists():
            return cand
        i = 2
        while True:
            cand = target_dir / f"{base} ({i}){ext}"
            if not cand.exists():
                return cand
            i += 1

    def assign_and_place(
        self,
        urls: list[str],
        group_id: int,
        op: str,
        root_dir: str,
        context_group_id: Optional[int] = None,
    ) -> tuple[list[str], list[tuple[str, str]]]:
        root_dir = str(Path(root_dir).expanduser())
        if not root_dir.strip():
            raise ValueError("请先设置 Mod 管理根目录")

        target_dir = self.ensure_group_folder(root_dir, int(group_id))

        ok: list[str] = []
        bad: list[tuple[str, str]] = []

        for url in urls:
            try:
                src: Optional[str] = None

                # prefer context group's managed file
                if context_group_id is not None:
                    src = self.get_group_file_for_url(url, int(context_group_id))

                if not src:
                    cur = self.conn.execute("SELECT file_path, file_name FROM downloads WHERE url=?", (url,))
                    r = cur.fetchone()
                    if r and r["file_path"]:
                        src = str(r["file_path"])
                    else:
                        src = self.get_any_managed_file(url)

                if not src or not os.path.exists(src):
                    raise FileNotFoundError("找不到本地文件路径")

                file_name = Path(src).name
                dst = self._non_conflict_path(target_dir, file_name)

                if op == "move":
                    shutil.move(src, str(dst))
                elif op == "copy":
                    shutil.copy2(src, str(dst))
                else:
                    raise ValueError("未知操作")

                # membership
                self.conn.execute(
                    "INSERT OR IGNORE INTO mod_group_map(url, group_id, is_primary, created_at) VALUES(?,?,1,?)",
                    (url, int(group_id), _now_ts()),
                )

                # managed file record
                self.conn.execute(
                    "INSERT INTO managed_files(url, group_id, file_path, file_name, op, updated_at) VALUES(?,?,?,?,?,?)\n"
                    "ON CONFLICT(url, group_id) DO UPDATE SET file_path=excluded.file_path, file_name=excluded.file_name, op=excluded.op, updated_at=excluded.updated_at",
                    (url, int(group_id), str(dst), dst.name, op, _now_ts()),
                )

                if op == "move":
                    self.conn.execute(
                        "UPDATE downloads SET file_path=?, file_name=? WHERE url=?",
                        (str(dst), dst.name, url),
                    )

                self.conn.commit()
                ok.append(url)
            except Exception as e:
                bad.append((url, str(e)))

        return ok, bad

    def move_or_copy_to_group(
        self,
        urls: list[str],
        group_id: int,
        op: str,
        managed_root: Optional[str] = None,
    ) -> tuple[list[str], list[tuple[str, str]]]:
        if not managed_root:
            raise ValueError("请先设置 Mod 管理根目录")
        return self.assign_and_place(urls=urls, group_id=int(group_id), op=op, root_dir=str(managed_root), context_group_id=None)
