from __future__ import annotations

import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from core.paths import get_app_dir
from core.clipboard import copy_text
from core.browser import open_url, open_path

from .dbx import ModManagerDB


def _safe_set_geometry(win: tk.Toplevel, geo: str | None) -> None:
    if not geo:
        return
    try:
        win.geometry(geo)
    except Exception:
        pass


class ModManagerWindow:
    def __init__(self, root: tk.Misc, cfg):
        self.cfg = cfg
        self.root = root
        self.win = tk.Toplevel(root)
        self.win.title("Mod 管理器")
        _safe_set_geometry(self.win, cfg.get("mod_manager.window_geometry"))

        # paths
        self.app_dir = get_app_dir()
        self.db_path = (cfg.get("downloader.db_path") or os.path.join(self.app_dir, "tsr_downloads.db")).strip()
        if not cfg.get("downloader.db_path"):
            cfg.set("downloader.db_path", self.db_path)
            try:
                cfg.save()
            except Exception:
                pass

        self.db = ModManagerDB(self.db_path)

        self.managed_root_var = tk.StringVar(value=(cfg.get("mod_manager.managed_root") or "").strip())
        self.keyword_var = tk.StringVar(value="")
        self.creator_var = tk.StringVar(value="全部")
        self.tag_var = tk.StringVar(value="全部")
        self.status_var = tk.StringVar(value="全部")
        self.current_group_id: int | None = None  # None means ALL
        self.current_view = "ALL"  # ALL / UNASSIGNED / GROUP

        self._build_ui()
        self._load_group_tree()
        self._load_filter_values()
        self.refresh_mods()

        self.win.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------- UI ----------------
    def _build_ui(self) -> None:
        outer = ttk.Frame(self.win, padding=10)
        outer.pack(fill=tk.BOTH, expand=True)

        # top bar
        top = ttk.Frame(outer)
        top.pack(fill=tk.X)

        ttk.Label(top, text="管理根目录:").pack(side=tk.LEFT)
        self.managed_root_cb = ttk.Combobox(
            top,
            textvariable=self.managed_root_var,
            width=52,
            values=self.cfg.get("mod_manager.managed_root_history", []),
        )
        self.managed_root_cb.pack(side=tk.LEFT, padx=(6, 4))
        ttk.Button(top, text="选择...", command=self.choose_managed_root).pack(side=tk.LEFT)
        ttk.Button(top, text="打开", command=self.open_managed_root).pack(side=tk.LEFT, padx=(4, 0))

        ttk.Separator(outer).pack(fill=tk.X, pady=8)

        paned = ttk.Panedwindow(outer, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)

        # left group tree
        left = ttk.Frame(paned, padding=(0, 0, 8, 0))
        paned.add(left, weight=1)
        ttk.Label(left, text="组别", font=("Segoe UI", 11, "bold")).pack(anchor="w")

        self.group_tree = ttk.Treeview(left, columns=("gid",), show="tree")
        self.group_tree.pack(fill=tk.BOTH, expand=True, pady=(6, 0))

        self.group_tree.bind("<<TreeviewSelect>>", self.on_group_select)
        self.group_tree.bind("<Double-1>", self.on_group_double)
        self.group_tree.bind("<Button-3>", self.on_group_right_click)

        btns = ttk.Frame(left)
        btns.pack(fill=tk.X, pady=6)
        ttk.Button(btns, text="新建组", command=self.add_group).pack(side=tk.LEFT)
        ttk.Button(btns, text="新建子组", command=self.add_subgroup).pack(side=tk.LEFT, padx=4)

        # right mod list
        right = ttk.Frame(paned)
        paned.add(right, weight=3)

        self.view_label = ttk.Label(right, text="全部 Mod", font=("Segoe UI", 11, "bold"))
        self.view_label.pack(anchor="w")

        filters = ttk.Frame(right)
        filters.pack(fill=tk.X, pady=(6, 4))

        ttk.Label(filters, text="搜索:").pack(side=tk.LEFT)
        ttk.Entry(filters, textvariable=self.keyword_var, width=22).pack(side=tk.LEFT, padx=(4, 10))

        ttk.Label(filters, text="作者:").pack(side=tk.LEFT)
        self.creator_cb = ttk.Combobox(filters, textvariable=self.creator_var, width=16, state="readonly")
        self.creator_cb.pack(side=tk.LEFT, padx=(4, 10))

        ttk.Label(filters, text="标签:").pack(side=tk.LEFT)
        self.tag_cb = ttk.Combobox(filters, textvariable=self.tag_var, width=16, state="readonly")
        self.tag_cb.pack(side=tk.LEFT, padx=(4, 10))

        ttk.Label(filters, text="状态:").pack(side=tk.LEFT)
        self.status_cb = ttk.Combobox(filters, textvariable=self.status_var, width=14, state="readonly")
        self.status_cb.pack(side=tk.LEFT, padx=(4, 10))

        ttk.Button(filters, text="刷新", command=self.refresh_mods).pack(side=tk.RIGHT)

        columns = ("title", "creator", "publish", "status", "file", "tags", "url")
        self.mod_tree = ttk.Treeview(right, columns=columns, show="headings", selectmode="extended")

        self.mod_tree.heading("title", text="标题")
        self.mod_tree.heading("creator", text="作者")
        self.mod_tree.heading("publish", text="发布时间")
        self.mod_tree.heading("status", text="状态")
        self.mod_tree.heading("file", text="文件")
        self.mod_tree.heading("tags", text="标签")
        self.mod_tree.heading("url", text="URL")

        self.mod_tree.column("title", width=240)
        self.mod_tree.column("creator", width=110)
        self.mod_tree.column("publish", width=110)
        self.mod_tree.column("status", width=110)
        self.mod_tree.column("file", width=220)
        self.mod_tree.column("tags", width=220)
        self.mod_tree.column("url", width=360)

        self.mod_tree.pack(fill=tk.BOTH, expand=True)
        self.mod_tree.bind("<Double-1>", self.on_mod_double)
        self.mod_tree.bind("<Button-3>", self.on_mod_right_click)

        actions = ttk.Frame(right)
        actions.pack(fill=tk.X, pady=6)
        ttk.Button(actions, text="复制到组别...", command=lambda: self.move_copy_selected(op="copy")).pack(
            side=tk.LEFT
        )
        ttk.Button(actions, text="移动到组别...", command=lambda: self.move_copy_selected(op="move")).pack(
            side=tk.LEFT, padx=6
        )
        ttk.Button(actions, text="打开本地文件", command=self.open_selected_local).pack(side=tk.RIGHT)

        self.status = ttk.Label(self.win, text="", anchor="w")
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

        # mod tree sort state
        self._sort_state: dict[str, int] = {c: 0 for c in columns}  # 0 none, 1 asc, -1 desc
        for c in columns:
            self.mod_tree.heading(c, command=lambda col=c: self.toggle_sort(col))

        # filter change refresh
        for w in (self.creator_cb, self.tag_cb, self.status_cb):
            w.bind("<<ComboboxSelected>>", lambda _e: self.refresh_mods())
        self.keyword_var.trace_add("write", lambda *_: self._schedule_refresh())

    def _schedule_refresh(self) -> None:
        # debounce typing
        if hasattr(self, "_refresh_after"):
            try:
                self.win.after_cancel(self._refresh_after)
            except Exception:
                pass
        self._refresh_after = self.win.after(250, self.refresh_mods)

    # -------------- groups --------------
    def _load_group_tree(self) -> None:
        self.group_tree.delete(*self.group_tree.get_children())

        # virtual roots
        self.group_tree.insert("", "end", iid="ALL", text="全部 Mod")
        self.group_tree.insert("", "end", iid="UNASSIGNED", text="未分组")

        groups = self.db.list_groups()
        # build parent -> children mapping
        children: dict[int | None, list[dict]] = {}
        for g in groups:
            children.setdefault(g["parent_id"], []).append(g)

        def add_nodes(parent_iid: str, parent_id: int | None) -> None:
            for g in sorted(children.get(parent_id, []), key=lambda x: x["name"]):
                iid = f"G:{g['id']}"
                self.group_tree.insert(parent_iid, "end", iid=iid, text=g["name"])
                add_nodes(iid, g["id"])

        add_nodes("", None)
        self.group_tree.item("ALL", open=True)

    def _selected_group(self) -> tuple[str | None, int | None]:
        sel = self.group_tree.selection()
        if not sel:
            return None, None
        iid = sel[0]
        if iid == "ALL":
            return "ALL", None
        if iid == "UNASSIGNED":
            return "UNASSIGNED", None
        if iid.startswith("G:"):
            try:
                return "GROUP", int(iid.split(":", 1)[1])
            except Exception:
                return None, None
        return None, None

    def on_group_select(self, _e=None) -> None:
        pass

    def on_group_double(self, _e=None) -> None:
        typ, gid = self._selected_group()
        if typ == "ALL":
            self.current_view = "ALL"
            self.current_group_id = None
            self.view_label.configure(text="全部 Mod")
        elif typ == "UNASSIGNED":
            self.current_view = "UNASSIGNED"
            self.current_group_id = None
            self.view_label.configure(text="未分组")
        elif typ == "GROUP":
            self.current_view = "GROUP"
            self.current_group_id = gid
            g = self.db.get_group(gid)
            self.view_label.configure(text=f"组别: {g['name']}" if g else "组别")
        self.refresh_mods()

    def on_group_right_click(self, event) -> None:
        iid = self.group_tree.identify_row(event.y)
        if iid:
            self.group_tree.selection_set(iid)

        typ, gid = self._selected_group()
        m = tk.Menu(self.win, tearoff=0)

        m.add_command(label="新建组", command=self.add_group)
        if typ == "GROUP":
            m.add_command(label="新建子组", command=self.add_subgroup)
            m.add_separator()
            m.add_command(label="重命名", command=self.rename_group)
            m.add_command(label="删除", command=self.delete_group)
            m.add_separator()
            m.add_command(label="打开文件夹", command=self.open_selected_group_folder)
        m.tk_popup(event.x_root, event.y_root)

    def choose_managed_root(self) -> None:
        p = filedialog.askdirectory(title="选择 Mod 管理根目录")
        if not p:
            return
        self.managed_root_var.set(p)
        self.cfg.set("mod_manager.managed_root", p)
        self.cfg.append_history("mod_manager.managed_root_history", p)
        try:
            self.cfg.save()
        except Exception:
            pass

    def open_managed_root(self) -> None:
        p = self.managed_root_var.get().strip()
        if p and os.path.isdir(p):
            open_path(p)
        else:
            messagebox.showinfo("提示", "请先设置有效的管理根目录")

    def open_selected_group_folder(self) -> None:
        typ, gid = self._selected_group()
        if typ != "GROUP" or gid is None:
            return
        root = self.managed_root_var.get().strip()
        if not root:
            messagebox.showinfo("提示", "请先设置管理根目录")
            return
        p = self.db.get_group_abs_path(gid, root)
        if p:
            os.makedirs(p, exist_ok=True)
            open_path(p)

    def add_group(self) -> None:
        name = self._ask_text("新建组", "组别名称:")
        if not name:
            return
        root = self.managed_root_var.get().strip()
        gid = self.db.create_group(name=name, parent_id=None, managed_root=root or None)
        self._load_group_tree()
        self.group_tree.selection_set(f"G:{gid}")

    def add_subgroup(self) -> None:
        typ, gid = self._selected_group()
        if typ != "GROUP" or gid is None:
            messagebox.showinfo("提示", "请先选择一个组别")
            return
        name = self._ask_text("新建子组", "子组名称:")
        if not name:
            return
        root = self.managed_root_var.get().strip()
        new_id = self.db.create_group(name=name, parent_id=gid, managed_root=root or None)
        self._load_group_tree()
        self.group_tree.selection_set(f"G:{new_id}")

    def rename_group(self) -> None:
        typ, gid = self._selected_group()
        if typ != "GROUP" or gid is None:
            return
        g = self.db.get_group(gid)
        if not g:
            return
        name = self._ask_text("重命名组别", "新名称:", initial=g["name"])
        if not name or name.strip() == g["name"]:
            return
        root = self.managed_root_var.get().strip()
        try:
            self.db.rename_group(gid, name.strip(), managed_root=root or None)
        except Exception as e:
            messagebox.showerror("失败", f"重命名失败:\n{e}")
            return
        self._load_group_tree()
        self.group_tree.selection_set(f"G:{gid}")

    def delete_group(self) -> None:
        typ, gid = self._selected_group()
        if typ != "GROUP" or gid is None:
            return
        if self.db.group_has_children(gid):
            messagebox.showinfo("提示", "该组别有子组，请先删除子组")
            return
        root = self.managed_root_var.get().strip()
        folder = self.db.get_group_abs_path(gid, root) if root else None

        choice = messagebox.askyesnocancel("删除组别", "删除组别会移除其分组关系。\n\n是否同时删除该组文件夹？")
        if choice is None:
            return
        delete_folder = bool(choice)
        try:
            self.db.delete_group(gid, delete_folder=delete_folder, managed_root=root or None)
        except Exception as e:
            messagebox.showerror("失败", f"删除失败:\n{e}")
            return

        # try delete folder
        if delete_folder and folder and os.path.isdir(folder):
            try:
                # only remove if empty
                if not os.listdir(folder):
                    os.rmdir(folder)
            except Exception:
                pass

        self._load_group_tree()
        self.current_view = "ALL"
        self.current_group_id = None
        self.view_label.configure(text="全部 Mod")
        self.refresh_mods()

    def _ask_text(self, title: str, prompt: str, initial: str = "") -> str | None:
        dlg = tk.Toplevel(self.win)
        dlg.title(title)
        dlg.transient(self.win)
        dlg.grab_set()

        ttk.Label(dlg, text=prompt).pack(anchor="w", padx=12, pady=(12, 6))
        var = tk.StringVar(value=initial)
        ent = ttk.Entry(dlg, textvariable=var, width=36)
        ent.pack(padx=12)
        ent.focus_set()

        out = {"v": None}

        def ok():
            out["v"] = var.get().strip()
            dlg.destroy()

        def cancel():
            dlg.destroy()

        btns = ttk.Frame(dlg)
        btns.pack(fill=tk.X, padx=12, pady=12)
        ttk.Button(btns, text="取消", command=cancel).pack(side=tk.RIGHT)
        ttk.Button(btns, text="确定", command=ok).pack(side=tk.RIGHT, padx=6)

        self.win.wait_window(dlg)
        return out["v"]

    # -------------- mods --------------
    def _load_filter_values(self) -> None:
        creators = ["全部"] + self.db.list_creators()
        tags = ["全部"] + self.db.list_tags()
        statuses = ["全部"] + self.db.list_statuses()
        self.creator_cb.configure(values=creators)
        self.tag_cb.configure(values=tags)
        self.status_cb.configure(values=statuses)
        if self.creator_var.get() not in creators:
            self.creator_var.set("全部")
        if self.tag_var.get() not in tags:
            self.tag_var.set("全部")
        if self.status_var.get() not in statuses:
            self.status_var.set("全部")

    def refresh_mods(self) -> None:
        keyword = self.keyword_var.get().strip()
        creator = self.creator_var.get()
        tag = self.tag_var.get()
        status = self.status_var.get()

        if self.current_view == "GROUP" and self.current_group_id is not None:
            rows = self.db.list_mods_in_group(
                group_id=self.current_group_id,
                keyword=keyword,
                creator=None if creator == "全部" else creator,
                tag=None if tag == "全部" else tag,
                status=None if status == "全部" else status,
            )
        elif self.current_view == "UNASSIGNED":
            rows = self.db.list_mods_unassigned(
                keyword=keyword,
                creator=None if creator == "全部" else creator,
                tag=None if tag == "全部" else tag,
                status=None if status == "全部" else status,
            )
        else:
            rows = self.db.list_mods_all(
                keyword=keyword,
                creator=None if creator == "全部" else creator,
                tag=None if tag == "全部" else tag,
                status=None if status == "全部" else status,
            )

        # apply sort
        sort_col, direction = self._current_sort()
        if sort_col and direction:
            rows.sort(key=lambda r: (r.get(sort_col) or "").lower() if isinstance(r.get(sort_col), str) else (r.get(sort_col) or 0))
            if direction < 0:
                rows.reverse()

        self.mod_tree.delete(*self.mod_tree.get_children())
        for r in rows:
            url = r.get("url") or ""
            tags = ",".join(r.get("tags") or [])
            file_name = r.get("file_name") or (os.path.basename(r.get("file_path") or "") or "")
            self.mod_tree.insert(
                "",
                "end",
                iid=url,
                values=(
                    r.get("title") or "",
                    r.get("creator") or "",
                    r.get("publish_date") or "",
                    r.get("status") or "",
                    file_name,
                    tags,
                    url,
                ),
            )

        self.status.configure(text=f"共 {len(rows)} 条 · DB: {self.db_path}")

    def _current_sort(self) -> tuple[str | None, int]:
        # return first non-zero sort
        for col, st in self._sort_state.items():
            if st != 0:
                return col, st
        return None, 0

    def toggle_sort(self, col: str) -> None:
        # reset other columns
        for k in self._sort_state:
            if k != col:
                self._sort_state[k] = 0
        st = self._sort_state.get(col, 0)
        if st == 0:
            self._sort_state[col] = 1
        elif st == 1:
            self._sort_state[col] = -1
        else:
            self._sort_state[col] = 0
        self.refresh_mods()

    def _get_cell_value(self, event) -> str:
        row_id = self.mod_tree.identify_row(event.y)
        col_id = self.mod_tree.identify_column(event.x)
        if not row_id or not col_id:
            return ""
        try:
            col_idx = int(col_id.replace("#", "")) - 1
        except Exception:
            return ""
        vals = self.mod_tree.item(row_id, "values")
        if 0 <= col_idx < len(vals):
            return str(vals[col_idx])
        return ""

    def on_mod_double(self, event) -> None:
        txt = self._get_cell_value(event)
        if txt:
            copy_text(txt)
            self.status.configure(text=f"已复制: {txt[:80]}")

    def on_mod_right_click(self, event) -> None:
        row_id = self.mod_tree.identify_row(event.y)
        if row_id:
            self.mod_tree.selection_set(row_id)

        cell_txt = self._get_cell_value(event)
        urls = list(self.mod_tree.selection())
        url = urls[0] if urls else ""

        m = tk.Menu(self.win, tearoff=0)
        if cell_txt:
            m.add_command(label="复制", command=lambda: copy_text(cell_txt))
        if url:
            m.add_command(label="复制 URL", command=lambda: copy_text(url))
            m.add_command(label="打开链接", command=lambda: open_url(url))
            m.add_separator()
            m.add_command(label="打开本地文件", command=self.open_selected_local)
            m.add_command(label="打开所在文件夹", command=self.open_selected_folder)
            m.add_separator()
            m.add_command(label="复制到组别...", command=lambda: self.move_copy_selected(op="copy"))
            m.add_command(label="移动到组别...", command=lambda: self.move_copy_selected(op="move"))
        m.tk_popup(event.x_root, event.y_root)

    def _selected_urls(self) -> list[str]:
        return list(self.mod_tree.selection())

    def open_selected_local(self) -> None:
        urls = self._selected_urls()
        if not urls:
            return
        root = self.managed_root_var.get().strip() or None
        path = self.db.get_best_local_path(urls[0], group_id=self.current_group_id if self.current_view == "GROUP" else None, managed_root=root)
        if path and os.path.exists(path):
            open_path(path)
        else:
            messagebox.showinfo("提示", "未找到本地文件路径")

    def open_selected_folder(self) -> None:
        urls = self._selected_urls()
        if not urls:
            return
        root = self.managed_root_var.get().strip() or None
        path = self.db.get_best_local_path(urls[0], group_id=self.current_group_id if self.current_view == "GROUP" else None, managed_root=root)
        if path and os.path.exists(path):
            open_path(os.path.dirname(path))
        else:
            messagebox.showinfo("提示", "未找到本地文件路径")

    def move_copy_selected(self, op: str) -> None:
        urls = self._selected_urls()
        if not urls:
            messagebox.showinfo("提示", "请先选择要操作的 mod")
            return

        gid = self._ask_group_id()
        if gid is None:
            return

        root = self.managed_root_var.get().strip()
        if not root:
            messagebox.showinfo("提示", "请先设置管理根目录")
            return

        self.cfg.set("mod_manager.managed_root", root)
        self.cfg.append_history("mod_manager.managed_root_history", root)
        try:
            self.cfg.save()
        except Exception:
            pass

        ok, bad = self.db.move_or_copy_to_group(urls, gid, op=op, managed_root=root)
        if bad:
            msg = "\n".join([f"{u}: {e}" for u, e in bad][:8])
            messagebox.showwarning("部分失败", f"成功 {len(ok)} 条，失败 {len(bad)} 条。\n\n{msg}")
        else:
            messagebox.showinfo("完成", f"已{ '移动' if op=='move' else '复制' } {len(ok)} 条")
        self._load_filter_values()
        self.refresh_mods()

    def _ask_group_id(self) -> int | None:
        # Prefer current selected group
        typ, gid = self._selected_group()
        if typ == "GROUP" and gid is not None:
            return gid

        # build a select dialog
        dlg = tk.Toplevel(self.win)
        dlg.title("选择组别")
        dlg.transient(self.win)
        dlg.grab_set()

        tv = ttk.Treeview(dlg, show="tree")
        tv.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        groups = self.db.list_groups()
        children: dict[int | None, list[dict]] = {}
        for g in groups:
            children.setdefault(g["parent_id"], []).append(g)

        def add_nodes(parent_iid: str, parent_id: int | None):
            for g in sorted(children.get(parent_id, []), key=lambda x: x["name"]):
                iid = f"G:{g['id']}"
                tv.insert(parent_iid, "end", iid=iid, text=g["name"])
                add_nodes(iid, g["id"])

        add_nodes("", None)

        out = {"gid": None}

        def ok():
            sel = tv.selection()
            if not sel:
                messagebox.showinfo("提示", "请选择一个组别")
                return
            iid = sel[0]
            if iid.startswith("G:"):
                out["gid"] = int(iid.split(":", 1)[1])
            dlg.destroy()

        def cancel():
            dlg.destroy()

        btns = ttk.Frame(dlg)
        btns.pack(fill=tk.X, padx=10, pady=(0, 10))
        ttk.Button(btns, text="取消", command=cancel).pack(side=tk.RIGHT)
        ttk.Button(btns, text="确定", command=ok).pack(side=tk.RIGHT, padx=6)

        self.win.wait_window(dlg)
        return out["gid"]

    # -------------- close --------------
    def on_close(self) -> None:
        try:
            self.cfg.set("mod_manager.window_geometry", self.win.geometry())
            self.cfg.set("mod_manager.managed_root", self.managed_root_var.get())
            self.cfg.append_history("mod_manager.managed_root_history", self.managed_root_var.get())
            self.cfg.save()
        except Exception:
            pass
        try:
            self.db.close()
        except Exception:
            pass
        self.win.destroy()


def open_window(root: tk.Misc, cfg) -> None:
    ModManagerWindow(root, cfg)
