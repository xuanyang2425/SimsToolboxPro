from __future__ import annotations

import importlib
import tkinter as tk
from tkinter import ttk, messagebox

from core.config_store import ConfigStore
from core.paths import get_app_dir


MODULES = [
    ("downloader", "TSR 批量下载器"),
    ("tray_converter", "Tray 版本转换器"),
    ("mod_manager", "Mod 管理器"),
]


class ToolboxApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.app_dir = get_app_dir()
        self.cfg = ConfigStore(self.app_dir)
        self.cfg.load()

        self.root.title("Sims 工具箱")
        self.root.geometry(self.cfg.get("main_window.geometry", "980x640"))
        self.root.minsize(820, 520)

        self._build_ui()
        self._update_status()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=12)
        outer.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(outer)
        left.pack(side=tk.LEFT, fill=tk.Y)

        ttk.Label(left, text="工具箱", font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(0, 10))

        for key, label in MODULES:
            ttk.Button(left, text=label, width=18, command=lambda k=key: self.open_module(k)).pack(
                fill=tk.X, pady=4
            )

        ttk.Separator(left).pack(fill=tk.X, pady=10)
        ttk.Button(left, text="打开配置目录", command=self.open_app_dir).pack(fill=tk.X)

        right = ttk.Frame(outer)
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(12, 0))

        ttk.Label(
            right,
            text=(
                "这是第 1 部分：主界面（工具箱面板）。\n\n"
                "后续你会把下载器 / 转换器 / Mod 管理器作为子窗口模块逐步叠加。\n"
                "你可以先点左侧按钮体验模块加载（当前为占位窗口）。"
            ),
            justify=tk.LEFT,
        ).pack(anchor="nw")

        self.status = ttk.Label(self.root, text="", anchor="w")
        self.status.pack(fill=tk.X, side=tk.BOTTOM)

    def _update_status(self) -> None:
        self.status.configure(text=f"配置目录: {self.app_dir}")

    def open_app_dir(self) -> None:
        from core.browser import open_path

        open_path(self.app_dir)

    def open_module(self, mod_key: str) -> None:
        try:
            m = importlib.import_module(f"modules.{mod_key}.ui")
        except Exception as e:
            messagebox.showerror("模块加载失败", f"无法加载模块 {mod_key}:\n\n{e}")
            return

        fn = getattr(m, "open_window", None)
        if not callable(fn):
            messagebox.showinfo("模块不可用", f"模块 {mod_key} 未提供 open_window(root, cfg)")
            return

        try:
            fn(self.root, self.cfg)
        except Exception as e:
            messagebox.showerror("模块运行失败", f"模块 {mod_key} 运行报错:\n\n{e}")

    def run(self) -> None:
        self.root.mainloop()

    def on_close(self) -> None:
        try:
            self.cfg.set("main_window.geometry", self.root.geometry())
            self.cfg.save()
        finally:
            self.root.destroy()
